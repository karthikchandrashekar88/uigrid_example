module.exports = {
  Server : require('./lib/server'),
  Client : require('./lib/client')
};
