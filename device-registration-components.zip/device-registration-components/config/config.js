var happner = require('happner');
var path = require('path');
var ownPath = path.join(__dirname, '../index.js');

var SERVER_HOST = "www.fieldpop.io";
var SERVER_PORT = 443;
var MESH_PORT = 80;
var PE_PORT = 81;

var SERVER_COMPONENT_NAME = "server";

var CLIENT_MESH_FILE_NAME = "ae.nedb";
var TUNNEL_FORWARD_ADDRESS = 'localhost:' + MESH_PORT;

var GET_DA_VALUE_INTERVAL = 5000;

var clientConfig = {
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    filename:CLIENT_MESH_FILE_NAME,
    port: MESH_PORT,
    persist: true,
    setOptions:{
      timeout:60000
    },
    defaultRoute: "mem",
    middleware:{
      security:{
        exclusions:[
          '/*'
        ]
      }
    }
  },
  modules: {
    fieldpopClient: {
      path: ownPath,
      create: {
        name: 'Client',
        type: 'sync'
      }
    },
    'tunnel-service': {
      path: '@smc/tunnel-service'
    },
    "fstProxy": {
      path: '@smc/proxy_component',
      constructor: {
        type: "sync",
        parameters: []
      }
    },
    "pe": {
      path: "@smc/pe-component"
    },
    "data_alarms": {
      path: '@smc/data_alarm_component',
      constructor: {
        type: "sync",
        parameters: []
      }
    }
  },
  components: {
    data: {},
    "pe": {
      moduleName: "pe",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  port: MESH_PORT,
                  hostname: '127.0.0.1',
                  enable_da: true,
                  store_enable: true,
                  save_delay_multiplier: 100,
                  get_da_list_period: 60000,
                  get_da_value_period: GET_DA_VALUE_INTERVAL
                }
              }
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    'tunnel-service': {
      moduleName: 'tunnel-service'
    },
    data_alarms: {
      moduleName: 'data_alarms',
      scope: 'component',
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [{}]
          },
          "stop": {
            type: "async",
            parameters: [{
              "name": "callback",
              "type": "callback",
              "required": true
            }]
          }
        }
      }
    },
    fieldpop: {
      name: "emu_client",
      moduleName: "fieldpopClient",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  serverMeshPort: SERVER_PORT,
                  serverMeshHost: SERVER_HOST,
                  serverComponentName: SERVER_COMPONENT_NAME,
                  tunnelForwardAddress: TUNNEL_FORWARD_ADDRESS,
                  protocol:'https',
                  aeRoot: "/node_js/app",
                  pe_component: "pe",
                  alarm_component: "data_alarms",
                  fieldpop_mgr: "fieldpop_user_mgr",
                  pe_port: PE_PORT,
                  tunnelServiceComponent: "tunnel-service"
                }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      },
      web: {
        routes: {
          client: ["gzip", "checkIndex", "static"],
          config: ["checkIndex", "multipart", "update_config", "static"]
        }
      },
      data: {
        routes:{
          deviceData : 'persist',
          fieldpop : 'persist',
          remoteEventCache: 'persist'
        }
      }
    },
    "www": {
      moduleName: "fstProxy",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        exclusive: true,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {name: 'options', required: true, value: {staticRoot: '/fst', port: PE_PORT}},
              {type: 'callback', required: true}
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    }
  }
};

var clientMesh;

var package = require("../package.json");
console.log("=-= Launching FieldPoP Client =-=");
console.log("Version: ", package.version);

happner.create(clientConfig, function (e, client) {
  if (e) return console.log(e);
  clientMesh = client;
  console.log('\ncreated Client\n\n');
});
