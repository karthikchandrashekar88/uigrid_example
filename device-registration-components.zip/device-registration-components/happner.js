
var DEFAULT_CLIENT_PORT = 8091;
var DEFAULT_SERVER_PORT = 8090;
var DEFAULT_SERVER_HOST = "localhost";
var DEFAULT_SERVER_COMPONENT_NAME = "device_registration_server";


var DEVICE_KEEPALIVE_INTERVAL = 10000;
var TUNNEL_HEALTH_INTERVAL = 5000;
var TUNNEL_SERVICE_ENDPOINT = "ws://192.168.1.5:8000";


module.exports = {
  configs: {
    client_default: {
      component: {
        config: {
          name:"fieldpop",
          scope: "component",
          startMethod: "start",
          schema: {
            "exclusive": false,
            "methods": {
              "start": {
                type: "async",
                parameters: [
                  {
                    "name": "options", "required": true, value: {
                    serverMeshPort: DEFAULT_SERVER_PORT,
                    serverMeshHost: DEFAULT_SERVER_HOST,
                    serverComponentName: DEFAULT_SERVER_COMPONENT_NAME
                    }
                  }
                ]
              },
              "stop": {
                type: "sync"
              }
            }
          },
          web: {
            routes: {
              web: ["gzip", "checkIndex", "static"]
            }
          },
          data: {
            routes: {
              'registrationData/*': 'persist'
            }
          }
        }
      }
    },
    server_default: {
      component: {
        config: {
          name:DEFAULT_SERVER_COMPONENT_NAME,
          scope: "component",
          startMethod: "start",
          stopMethod: "stop",
          schema: {
            "exclusive": false,
            "methods": {
              "start": {
                type: "sync",
                parameters: [
                  {
                    "name": "options", "required": true, value: {
                    deviceKeepaliveInterval: DEVICE_KEEPALIVE_INTERVAL,
                    tunnelHealthInterval: TUNNEL_HEALTH_INTERVAL,
                    tunnelServiceEndpoint : TUNNEL_SERVICE_ENDPOINT
                    }
                  }
                ]
              },
              "stop": {
                type: "sync"
              }
            }
          }
        }
      }
    }
  }
};
