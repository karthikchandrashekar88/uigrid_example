# device_registration_components

+[![Build Status](https://travis-ci.com/FieldServer/device-registration-components.svg?token=HPAyz8BhzPLszVxys36G&branch=master)](https://travis-ci.com/FieldServer/device-registration-components)

FieldPoP device registration client and server

### Local test
 To test locally, run:

> gulp pack_local

> node test/emu_test/a-register_device_web_page.js

Register device at: localhost:8091/client/web

Change mesh config at: localhost:8091/client/config
