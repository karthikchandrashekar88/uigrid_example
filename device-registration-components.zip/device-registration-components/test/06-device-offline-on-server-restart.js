var should = require('chai').should();
var happner = require('happner');
var path = require('path');
var fs = require('fs');
var async = require('async');
var ownPath = path.join(__dirname, '../index.js');

var SERVER_HOST = "localhost";
var SERVER_PORT = 8100;
var CLIENT_PORT = 8101;

var SERVER_COMPONENT_NAME = "server";
var SERVER_MESH_NAME = require('shortid').generate();

var DEVICE_KEEPALIVE_INTERVAL = 500;
var TUNNEL_HEALTH_INTERVAL = 5000;
var TUNNEL_SERVICE_ENDPOINT = "ws://192.168.1.5:8000";


var serverConfig = {
  //name: SERVER_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: SERVER_PORT,
    persist: true,
    defaultRoute: 'persist',
    filename: './test/ut_6.nedb'
  },
  modules: {
    server: {
      path: ownPath,
      create: {
        name: 'Server',
        type: 'sync'
      }
    }
  },
  components: {
    data: {},
    server: {
      name: "server",
      moduleName: "server",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options", "required": true, value: {
                deviceKeepaliveInterval: DEVICE_KEEPALIVE_INTERVAL,
                tunnelHealthInterval: TUNNEL_HEALTH_INTERVAL,
                tunnelServiceEndpoint: TUNNEL_SERVICE_ENDPOINT,
                protocol: 'http'
              }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      }
    }
  }
};

var test_filename = path.basename(__filename);

describe(test_filename, function () {
  var clientMesh;
  var serverMesh;
  var fst_bridge_emu;

  before(function (done) {
    this.timeout(10000);

    var db_src_path = path.join(__dirname, "./databases/ut_6.nedb");
    var db_dest_path = path.join(__dirname, "./ut_6.nedb");

    // make sure we get the unchanged db
    fs.exists(db_dest_path, function (exists) {
      if (exists) {
        fs.unlink(db_dest_path, link_old_db);
      }
      else {
        link_old_db();
      }
    });
    function link_old_db() {
      fs.link(db_src_path, db_dest_path, function () {
        done();
      });
    }

  });

  after(function (done) {
    async.parallel([
        function (cb) {
          if (!fst_bridge_emu) return cb();
          fst_bridge_emu.shutdown(cb);
        },
        function (cb) {
          if (!clientMesh) return cb();
          clientMesh.stop(cb)
        },
        function (cb) {
          if (!serverMesh) return cb();
          serverMesh.stop(cb);
        }],
      done
    );
  });

  it('a - When the server restarts, it should mark old devices as offline', function (done) {
    var status_count = 0;
    this.timeout(5000);
    var client_device_id = null;
    var kill_client = false;

    happner.create(serverConfig, function (err, server) {
      if (err) return console.log(err);
      serverMesh = server;

      serverMesh.event[SERVER_COMPONENT_NAME].on("deviceStatus/*", handleStatusEvent, function (err) {
        if (err) console.log(err);
        should.not.exist(err);
      });
    });

    function handleStatusEvent(message, meta) {
      message.deviceOnline.should.eql(false);
      done();
    }
  });
});


function getOemAdminGroup() {
  var regesterDeviceMethodPath = "/" + SERVER_MESH_NAME + "/" + SERVER_COMPONENT_NAME + "/registerDevice";

  var oemAdminGroup = {
    name: "OEM Admin",
    permissions: {
      methods: {}
    }
  };

  oemAdminGroup.permissions.methods[regesterDeviceMethodPath] = {authorized: true};

  return oemAdminGroup;
}

var OemUser = {
  username: 'user@oem.com',
  password: 'TEST PWD',
  customData: {
    oem: "OEM A",
    company: "Enterprise X"
  }
};
