var should = require('chai').should();
var happner = require('happner');
var path = require('path');
var FstBridgeEmu = require('@smc/fst_bridge_emu');
var async = require('async');
var ownPath = path.join(__dirname, '../index.js');

var SERVER_HOST = "localhost";
var SERVER_PORT = 8082;
var CLIENT_PORT = 8083;
var EMU_PORT = 8080;

var SERVER_COMPONENT_NAME = "server";
var SERVER_MESH_NAME = require('shortid').generate();

var DEVICE_KEEPALIVE_INTERVAL = 500;
var TUNNEL_HEALTH_INTERVAL = 5000;
var TUNNEL_SERVICE_ENDPOINT = "ws://192.168.1.5:8000";

var clientConfig = {
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: CLIENT_PORT,
    persist: true,
    defaultRoute: "mem"
  },
  modules: {
    client: {
      path: ownPath,
      create: {
        name: 'Client',
        type: 'sync'
      }
    },
    "pe": {
      path: "@smc/pe-component"
    }
  },
  components: {
    data: {},
    "pe": {
      moduleName: "pe",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {port: EMU_PORT}
              }
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    client: {
      name: "client",
      moduleName: "client",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  serverMeshPort: SERVER_PORT,
                  serverMeshHost: SERVER_HOST,
                  serverComponentName: SERVER_COMPONENT_NAME,
                  protocol: 'http'
                }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      },
      web: {
        routes: {
          web: ["gzip", "checkIndex", "static"]
        }
      },
      data: {
        routes: {
          //'registrationData/*': 'persist'
        }
      }
    }
  }
};


var serverConfig = {
  name: SERVER_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: SERVER_PORT,
    persist: true,
    defaultRoute: 'mem'
  },
  modules: {
    server: {
      path: ownPath,
      create: {
        name: 'Server',
        type: 'sync'
      }
    }
  },
  components: {
    data: {},
    server: {
      moduleName: 'server',
      config: "server_default"
    }
  }
};


var test_filename = path.basename(__filename);

describe(test_filename, function () {
  var clientMesh;
  var serverMesh;
  var fst_bridge_emu = null;

  before(function (done) {
    this.timeout(10000);


    fst_bridge_emu = FstBridgeEmu.emu({httpPort: EMU_PORT});
    fst_bridge_emu.on('online', function () {
      happner.create(serverConfig, function (e, server) {
        serverMesh = server;
        happner.create(clientConfig, function (e, client) {
          clientMesh = client;
          done(e);
        });
      });
    });

  });

  after(function (done) {
    async.parallel([
        function (cb) {
          if (!fst_bridge_emu) return cb();
          fst_bridge_emu.shutdown(cb);
        },
        function (cb) {
          if (!clientMesh) return cb();
          clientMesh.stop(cb)
        },
        function (cb) {
          if (!serverMesh) return cb();
          serverMesh.stop(cb);
        }],
      done
    );
  });

  it('a - client should not login to server mesh with incorrect credentials', function (done) {
    var credentials = {
      username: '_ADMIN',
      password: 'bad-password'
    };
    clientMesh.exchange.client.login(credentials, function (err) {
      err.should.be.a("Error");
      done();
    });
  });

  it('b - client should login to server mesh', function (done) {
    var credentials = {
      username: '_ADMIN',
      password: 'password'
    };
    clientMesh.exchange.client.login(credentials, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
      done();
    });
  });

});
