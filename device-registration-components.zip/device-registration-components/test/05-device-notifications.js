var should = require('chai').should();
var happner = require('happner');
var path = require('path');
var FstBridgeEmu = require('@smc/fst_bridge_emu');
var async = require('async');
var ownPath = path.join(__dirname, '../index.js');

var SERVER_HOST = "localhost";
var SERVER_PORT = 8098;
var CLIENT_PORT = 8099;
var EMU_PORT = 8080;
var SERVER_COMPONENT_NAME = "server";
var SERVER_MESH_NAME = require('shortid').generate();

// timeout needs to be long enough to not trigger offline notifications while the server is shutting down
var DEVICE_KEEPALIVE_INTERVAL = 1500;
var TUNNEL_HEALTH_INTERVAL = 5000;
var TUNNEL_SERVICE_ENDPOINT = "ws://192.168.1.5:8000";

var NOTIFICATION_CACHE_COUNT = 10;

var clientConfig = {
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: CLIENT_PORT,
    persist: true,
    defaultRoute: "mem",
    setOptions: {
      timeout: 2000
    }
  },
  modules: {
    "pe": {
      path: "@smc/pe-component"
    },
    client: {
      path: ownPath,
      create: {
        name: 'Client',
        type: 'sync'
      }
    }
  },
  components: {
    data: {},
    "pe": {
      moduleName: "pe",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {port: EMU_PORT}
              }
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    client: {
      name: "client",
      moduleName: "client",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  serverMeshPort: SERVER_PORT,
                  serverMeshHost: SERVER_HOST,
                  serverComponentName: SERVER_COMPONENT_NAME,
                  notificationCacheCount: NOTIFICATION_CACHE_COUNT,
                  protocol: 'http'
                }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      },
      web: {
        routes: {
          web: ["gzip", "checkIndex", "static"]
        }
      },
      data: {
        routes: {
          //'registrationData/*': 'persist'
        }
      }
    }
  }
};


var serverConfig = {
  name: SERVER_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: SERVER_PORT,
    persist: true,
    defaultRoute: 'persist',
    setOptions: {
      timeout: 2000
    }
  },
  modules: {
    server: {
      path: ownPath,
      create: {
        name: 'Server',
        type: 'sync'
      }
    }
  },
  components: {
    data: {},
    server: {
      name: "server",
      moduleName: "server",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options", "required": true, value: {
                deviceKeepaliveInterval: DEVICE_KEEPALIVE_INTERVAL,
                tunnelHealthInterval: TUNNEL_HEALTH_INTERVAL,
                tunnelServiceEndpoint: TUNNEL_SERVICE_ENDPOINT
              }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      }
    }
  }
};

var test_filename = path.basename(__filename);

describe(test_filename, function () {
  var clientMesh;
  var serverMesh;
  var fst_bridge_emu;

  this.timeout(10000);

  before(function (done) {
    var savedUser = null;
    var savedGroup = null;


    fst_bridge_emu = FstBridgeEmu.emu({httpPort: EMU_PORT});
    fst_bridge_emu.on('online', function () {
      happner.create(serverConfig)
        .then(addGroup)
        .then(addUser)
        .then(linkUser)
        .then(createClient)
        .then(saveClient)
        .catch(function (err) {
          done(err);
        });
    });


    function addGroup(server) {
      serverMesh = server;
      return serverMesh.exchange.security.addGroup(getOemAdminGroup());
    }

    function addUser(group) {
      savedGroup = group;
      return serverMesh.exchange.security.addUser(OemUser);
    }

    function linkUser(user) {
      savedUser = user;
      return serverMesh.exchange.security.linkGroup(savedGroup, savedUser);
    }

    function createClient() {
      return happner.create(clientConfig);
    }

    function saveClient(client) {
      clientMesh = client;
      done();
    }
  });

  after(function (done) {
    async.parallel([
        function (cb) {
          if (!fst_bridge_emu) return cb();
          fst_bridge_emu.shutdown(cb);
        },
        function (cb) {
          if (!clientMesh) return cb();
          var shuttingDown = true;
          clientMesh.stop(function () {
            clientMesh = undefined;
            if (shuttingDown) {
              shuttingDown = false;
              console.log('INFO: clientMesh shut down normally');
              cb();
            }
          });
          setTimeout(function catchBadShutdown() {
            if (shuttingDown) {
              shuttingDown = false;
              console.log('WARNING: clientMesh did not shut down, ignoring');
              cb();
            }
          }, 5000);
        },
        function (cb) {
          if (!serverMesh) return cb();
          serverMesh.stop(cb);
        }],
      done
    );
  });

  it('a - client should generate a notification', function (done) {
    var status_count = 0;
    this.timeout(5000);
    var client_device_id = null;
    var kill_client = false;
    var event_path;

    serverMesh.event[SERVER_COMPONENT_NAME].on("deviceStatus/*", handleStatusEvent, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    serverMesh.event[SERVER_COMPONENT_NAME].on("notifications/device_online", handleOnlineNotification, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    serverMesh.event.server.on("deviceRegistered/*", handleDeviceRegistrationEvent, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    var deviceDetails = {
      description: "FieldPoP test device",
      location: "Somewhere east of somewhere",
      name: "Test device 1"
    };

    clientMesh.exchange.client.registerDevice(OemUser, deviceDetails, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    function handleDeviceRegistrationEvent(message) {
      message.should.property("deviceId");
      client_device_id = message.deviceId;

      event_path = "notifications/" + client_device_id + '/event_key*';

      serverMesh.event[SERVER_COMPONENT_NAME].on(event_path, handleDeviceNotificationEvent, function (err) {
        if (err) console.log(err);
        should.not.exist(err);
      });

      serverMesh.event.server.off("deviceRegistered/*", function (err) {
        if (err) console.log(err);
        should.not.exist(err);
      });
    }

    function handleStatusEvent(message, meta) {
      message.deviceOnline.should.eql(true);
      clientMesh.exchange.client.generateDeviceNotification("event_key", 'event_data');
    }

    function handleOnlineNotification(message, meta) {
      message.should.property("notificationMessage", "FieldPoP Connection Established");
      message.should.property("notificationType", "Device Online");
      message.should.property("macAddress");
      message.should.property("oem");
      message.should.property("eventDate");
      message.should.property("company");

      var key = meta.path.split('/').pop();
      key.should.eql('Device Online');

      serverMesh.event[SERVER_COMPONENT_NAME].off("notifications/*", function (err) {
        should.not.exist(err);
      });
    }

    function handleDeviceNotificationEvent(data, meta) {
      //console.log(data);
      data.should.property("notificationMessage", "event_data");
      data.should.property("notificationType", "event_key");
      data.should.property("macAddress");
      data.should.property("eventDate");

      var key = meta.path.split('/').pop();
      key.should.eql('event_key');

      serverMesh.event[SERVER_COMPONENT_NAME].off(event_path, function (err) {
        if (err) console.log(err);
        should.not.exist(err);
        done();
      });
    }

  });

  it('b - client should cache notification if the server is offline', function (done) {
    var status_count = 0;
    this.timeout(15000);
    var client_device_id = null;
    var kill_client = false;
    var notification_count = 0;

    var gen_count = NOTIFICATION_CACHE_COUNT * 2;

    serverMesh.stop();

    setTimeout(gen_event_then_start_server, 3000);

    function gen_event_then_start_server() {
      // generate two notifications

      for (var i = 0; i < gen_count; i++) {
        clientMesh.exchange.client.generateDeviceNotification("event_key", 'event_data');
      }

      happner.create(serverConfig).then(function (server) {
        serverMesh = server;


        serverMesh.event[SERVER_COMPONENT_NAME].on("notifications/*", handleDeviceNotificationEvent, function (err) {
          if (err) console.log(err);
          should.not.exist(err);
          setTimeout(check_count, 5000)
        });
      });
    }

    function handleDeviceNotificationEvent(data, meta) {
      //console.log(data);
      data.should.property("notificationMessage", "event_data");
      data.should.property("notificationType", "event_key");
      data.should.property("macAddress");
      data.should.property("oem");
      data.should.property("eventDate");
      data.should.property("company");

      notification_count++;

      var key = meta.path.split('/').pop();
      key.should.eql('event_key');
    }

    function check_count() {
      notification_count.should.eql(NOTIFICATION_CACHE_COUNT);
      serverMesh.event[SERVER_COMPONENT_NAME].off("notifications/*", done);
    }
  });


  it('c - server should generate device offline notification', function (done) {
    this.timeout(15000);
    var client_device_id = null;
    var kill_client = false;
    var notification_count = 0;

    serverMesh.event[SERVER_COMPONENT_NAME].on("notifications/*", handleDeviceNotificationEvent, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
      clientMesh.stop();
    });

    function handleDeviceNotificationEvent(data, meta) {
      //console.log(data);
      data.should.property("notificationMessage", "FieldPoP Connection Lost");
      data.should.property("notificationType", "Device Offline");
      data.should.property("macAddress");
      data.should.property("oem");
      data.should.property("eventDate");
      data.should.property("company");

      var key = meta.path.split('/').pop();
      key.should.eql('device_offline');

      serverMesh.event[SERVER_COMPONENT_NAME].off("notifications/*", done);
    }
  });
});


function getOemAdminGroup() {
  var regesterDeviceMethodPath = "/" + SERVER_MESH_NAME + "/" + SERVER_COMPONENT_NAME + "/registerDevice";

  var oemAdminGroup = {
    name: "OEM Admin",
    permissions: {
      methods: {}
    }
  };

  oemAdminGroup.permissions.methods[regesterDeviceMethodPath] = {authorized: true};

  return oemAdminGroup;
}

var OemUser = {
  username: 'user@oem.com',
  password: 'TEST PWD',
  custom_data: {
    oem: "OEM A",
    company: "Enterprise X"
  }
};
