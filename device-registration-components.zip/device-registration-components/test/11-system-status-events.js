var should = require('chai').should();
var happner = require('happner');
var path = require('path');
var fstBridgeEmu = require('@smc/fst_bridge_emu');
var Promise = require('bluebird');
var async = require('async');
var ownPath = path.join(__dirname, '../index.js');

var SERVER_HOST = "localhost";
var SERVER_PORT = 8098;
var CLIENT_PORT = 8099;

var BRIDGE_PORT = 9000;

var SERVER_COMPONENT_NAME = "server";
var SERVER_MESH_NAME = require('shortid').generate();
var CLIENT_MESH_NAME = require('shortid').generate();

var DEVICE_KEEPALIVE_INTERVAL = 500;
var TUNNEL_HEALTH_INTERVAL = 5000;
var TUNNEL_SERVICE_ENDPOINT = "ws://192.168.1.5:8000";

var NOTIFICATION_CACHE_COUNT = 10;

var clientConfig = {
  name: CLIENT_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: CLIENT_PORT,
    persist: true,
    defaultRoute: "persist",
    setOptions: {
      timeout: 2000
    }
  },
  modules: {
    client: {
      path: ownPath,
      create: {
        name: 'Client',
        type: 'sync'
      }
    },
    "pe": {
      path: '@smc/pe-component',
      constructor: {
        type: "sync",
        parameters: []
      }
    },
    "dataAlarm": {
      path: "@smc/data_alarm_component",
      create: {
        type: 'sync'
      }
    }
  },
  components: {
    data: {},
    "pe": {
      moduleName: "pe",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  port: BRIDGE_PORT
                }
              }
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    data_alarms: {
      moduleName: 'dataAlarm',
      scope: 'component',
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [{}]
          },
          "stop": {
            type: "async",
            parameters: [{
              "name": "callback",
              "type": "callback",
              "required": true
            }]
          }
        }
      }
    },
    client: {
      name: "client",
      moduleName: "client",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  serverMeshPort: SERVER_PORT,
                  serverMeshHost: SERVER_HOST,
                  serverComponentName: SERVER_COMPONENT_NAME,
                  notificationCacheCount: NOTIFICATION_CACHE_COUNT,
                  protocol: 'http',
                  remoteEventForward: [
                    {
                      component: 'pe',
                      path: '*'
                    }
                  ]
                }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      },
      web: {
        routes: {
          web: ["gzip", "checkIndex", "static"]
        }
      },
      data: {
        routes: {
          //'registrationData/*': 'persist'
        }
      }
    }
  }
};

var test_filename = path.basename(__filename);

describe(test_filename, function () {
  var clientMesh;
  var serverMesh;
  var fst_bridge_emu;

  before(function (done) {
    var savedUser = null;
    var savedGroup = null;
    this.timeout(10000);

    // don't create the server yet, test startup events
    createClient()
      .then(saveClient)
      .catch(function (err) {
        done(err);
      });

    function createClient() {
      return happner.create(clientConfig);
    }

    function saveClient(client) {
      clientMesh = client;
      done();
    }
  });

  after(function (done) {
    async.parallel([
        function (cb) {
          if (!fst_bridge_emu) return cb();
          fst_bridge_emu.shutdown(cb);
        },
        function (cb) {
          if (!clientMesh) return cb();
          clientMesh.stop(cb)
        },
        function (cb) {
          if (!serverMesh) return cb();
          serverMesh.stop(cb);
        }],
      done
    );
  });

  it('should not crash when not connected and emitting an event', function () {
    this.timeout(3000);
    var path = 'test_mesh_path';
    var utils = {
      createEventForSystemGroup: function createEventForSystemGroup() {
        return clientMesh.exchange.data_alarms.addDataAlarm({
          alarm_id: 'test_system_alarm',
          mesh_path: path,
          alarm_setpoint: 10,
          falling_alarm: false,
          alarm_value_deadband: 0,
          alarm_group_id: "fieldpop_system_alarm"
        })
      },
      triggerAlarm: new Promise.promisify(function triggerAlarm(result, callback) {
        clientMesh.exchange.data.set(path, 12, callback);
      }),
      getAlarmGroupStatus: new Promise.promisify(function (result, callback) {
        clientMesh.exchange.data.get('data_alarms/alarm_groups/fieldpop_system_alarm', callback);
      }),
      waitForEvents: new Promise.promisify(function (result, callback) {
        setTimeout(callback.bind(this, null, result), 500);
      }),
      checkAlarmStatus: function (result) {
        result.alarm.should.eql(true);
      }
    };

    return utils.createEventForSystemGroup()
      .then(utils.triggerAlarm)
      .then(utils.waitForEvents)
      .then(utils.getAlarmGroupStatus)
      .then(utils.checkAlarmStatus)
  });

});


function getOemAdminGroup() {
  var registerDeviceMethodPath = "/" + SERVER_MESH_NAME + "/" + SERVER_COMPONENT_NAME + "/registerDevice";

  var oemAdminGroup = {
    name: "OEM Admin",
    permissions: {
      methods: {}
    }
  };

  oemAdminGroup.permissions.methods[registerDeviceMethodPath] = {authorized: true};

  return oemAdminGroup;
}

var OemUser = {
  username: 'user@oem.com',
  password: 'TEST PWD',
  customData: {
    oem: "OEM A",
    company: "Enterprise X"
  }
};
