var should = require('chai').should();
var happner = require('happner');
var path = require('path');
var fstBridgeEmu = require('@smc/fst_bridge_emu');
var async = require('async');

var ownPath = path.join(__dirname, '../index.js');

var SERVER_HOST = "localhost";
var SERVER_PORT = 8098;
var CLIENT_PORT = 8099;

var BRIDGE_PORT = 9000;

var SERVER_COMPONENT_NAME = "server";
var SERVER_MESH_NAME = require('shortid').generate();
var CLIENT_MESH_NAME = require('shortid').generate();

var DEVICE_KEEPALIVE_INTERVAL = 500;
var TUNNEL_HEALTH_INTERVAL = 5000;
var TUNNEL_SERVICE_ENDPOINT = "ws://192.168.1.5:8000";

var NOTIFICATION_CACHE_COUNT = 100;

var clientConfig = {
  name: CLIENT_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: CLIENT_PORT,
    persist: true,
    defaultRoute: "persist",
    setOptions: {
      timeout: 2000
    }
  },
  modules: {
    client: {
      path: ownPath,
      create: {
        name: 'Client',
        type: 'sync'
      }
    },
    "pe": {
      path: '@smc/pe-component',
      constructor: {
        type: "sync",
        parameters: []
      }
    },
    event: {
      path: path.join(__dirname, 'lib', '10-event-component'),
      constructor: {
        type: "sync",
        parameters: []
      }
    }
  },
  components: {
    data: {},
    "pe": {
      moduleName: "pe",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  port: BRIDGE_PORT
                }
              }
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    event: {
      moduleName: "event",
      scope: "component",
      schema: {
        "exclusive": false
      }
    },
    client: {
      name: "client",
      moduleName: "client",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  serverMeshPort: SERVER_PORT,
                  serverMeshHost: SERVER_HOST,
                  serverComponentName: SERVER_COMPONENT_NAME,
                  notificationCacheCount: NOTIFICATION_CACHE_COUNT,
                  protocol: 'http',
                  remoteEventForward: [
                    {
                      component: 'pe',
                      path: '*'
                    },
                    {
                      component: 'event',
                      path: 'event'
                    }
                  ]
                }
              }
            ]
          }
          ,
          "stop": {
            type: "sync"
          }
        }
      },
      web: {
        routes: {
          web: ["gzip", "checkIndex", "static"]
        }
      },
      data: {
        routes: {
          //'registrationData/*': 'persist'
        }
      }
    }
  }
};


var serverConfig = {
  name: SERVER_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: SERVER_PORT,
    persist: true,
    defaultRoute: 'persist',
    setOptions: {
      timeout: 2000
    }
  },
  modules: {
    server: {
      path: ownPath,
      create: {
        name: 'Server',
        type: 'sync'
      }
    }
  },
  components: {
    data: {},
    server: {
      name: "server",
      moduleName: "server",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options", "required": true, value: {
                deviceKeepaliveInterval: DEVICE_KEEPALIVE_INTERVAL,
                tunnelHealthInterval: TUNNEL_HEALTH_INTERVAL,
                tunnelServiceEndpoint: TUNNEL_SERVICE_ENDPOINT
              }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      }
    }
  }
};

var test_filename = path.basename(__filename);

describe(test_filename, function () {
  var clientMesh;
  var serverMesh;
  var fst_bridge_emu;

  before(function (done) {
    var savedUser = null;
    var savedGroup = null;
    this.timeout(10000);

    happner.create(serverConfig)
      .then(addGroup)
      .then(addUser)
      .then(linkUser)
      .then(createClient)
      .then(saveClient)
      .catch(function (err) {
        done(err);
      });

    function addGroup(server) {
      serverMesh = server;
      return serverMesh.exchange.security.addGroup(getOemAdminGroup());
    }

    function addUser(group) {
      savedGroup = group;
      return serverMesh.exchange.security.addUser(OemUser);
    }

    function linkUser(user) {
      savedUser = user;


      return serverMesh.exchange.security.linkGroup(savedGroup, savedUser);
    }

    function createClient() {
      return happner.create(clientConfig);
    }

    function saveClient(client) {
      clientMesh = client;
      done();
    }
  });

  after(function (done) {
    async.parallel([
        function (cb) {
          if (!fst_bridge_emu) return cb();
          fst_bridge_emu.shutdown(cb);
        },
        function (cb) {
          if (!clientMesh) return cb();
          clientMesh.stop(cb)
        },
        function (cb) {
          if (!serverMesh) return cb();
          serverMesh.stop(cb);
        }],
      done
    );
  });

  it('a - the client should forward edge device events to the server for re-emitting', function (done) {
    var status_count = 0;
    this.timeout(10000);
    var client_device_id = null;
    var kill_client = false;
    var event_path;
    var newMessage = 'new system status message';


    serverMesh.event[SERVER_COMPONENT_NAME].on("deviceStatus/*", handleStatusEvent, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    var deviceDetails = {
      description: "FieldPoP test device",
      location: "Somewhere east of somewhere",
      name: "Test device 10"
    };

    clientMesh.exchange.client.registerDevice(OemUser, deviceDetails, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    function handleStatusEvent(message) {
      message.should.property("deviceId");
      client_device_id = message.deviceId;

      event_path = "edge/" + client_device_id + '/*';

      serverMesh.event[SERVER_COMPONENT_NAME].on(event_path, handleForwardEvent, function (err) {
        if (err) console.log(err);
        should.not.exist(err);

        fst_bridge_emu = fstBridgeEmu.sim({httpPort: BRIDGE_PORT}, function () {
          fst_bridge_emu.setSystemStatus("System Status", newMessage);
        });
      });

      serverMesh.event.server.off("deviceStatus/*", function (err) {
        if (err) console.log(err);
        should.not.exist(err);
      });
    }

    function handleForwardEvent(data, meta) {
      data.should.property("status", newMessage);
      data.should.property("deviceId", client_device_id);

      var key = meta.path.split(client_device_id).pop();
      key.should.eql('/pe/system_status');

      serverMesh.event[SERVER_COMPONENT_NAME].off(event_path, function (err) {
        if (err) console.log(err);
        should.not.exist(err);
        done();
      });
    }

  });

  it('b - client should cache edge events if the server is offline', function (done) {
    var status_count = 0;
    this.timeout(25000);
    var client_device_id = null;
    var kill_client = false;
    var notification_count = 0;
    var newMessage = 'new system status message';

    serverMesh.stop();

    fst_bridge_emu.setSystemStatus("System Status", newMessage + "_A");
    fst_bridge_emu.setSystemStatus("Firmware Status", newMessage + "_B");
    fst_bridge_emu.setSystemStatus("Configuration Status", newMessage + "_C");

    setTimeout(createServerAgain, 2000);

    function createServerAgain() {

      clientMesh.stop();

      happner.create(serverConfig).then(function (server) {
        serverMesh = server;

        serverMesh.event[SERVER_COMPONENT_NAME].on("edge/*", handleForwardEvent, function (err) {
          if (err) console.log(err);
          should.not.exist(err);
          setTimeout(startClient, 1000);
        });
      });
    }

    function startClient() {
      happner.create(clientConfig).then(function (client) {
        clientMesh = client;
        setTimeout(check_count, 5000)
      });
    }

    function handleForwardEvent(data, meta) {
      data.should.property("status");
      data.should.property("deviceId");

      notification_count++;
    }

    function check_count() {
      notification_count.should.eql(3);

      serverMesh.event[SERVER_COMPONENT_NAME].off("edge/*", function (err) {
        if (err) console.log(err);
        should.not.exist(err);
        done();
      })
    }

  });

  it('c - should send the events in order when it comes online again', function () {
    this.timeout(20000);

    var message = 0;
    var timer;

    var utils = {
      waitForOffline: Promise.promisify(function (result, callback) {
        clientMesh.event.client.on('client/disconnect', function () {
          clientMesh.event.client.off('client/disconnect', callback);
        })
      }),
      waitForTime: Promise.promisify(function (result, callback) {
        setTimeout(callback, 2000);
      }),
      waitForEvents: Promise.promisify(function (result, callback) {
        var messageReceived = [];
        serverMesh.event.server.on('edge/*', function (message, _meta) {
          var messageRec = parseInt(message.value);
          messageReceived[messageRec] = true;

          if (messageRec == 0) return;
          if (messageReceived[messageRec - 1] !== true) {
            clearInterval(timer);
            return callback("Messages received out of order " + messageRec);
          }
          if (messageRec == 100) {
            clearInterval(timer);
            callback();
          }
        }, function () {
        })
      }),
      startTimer: function () {
        timer = setInterval(utils.triggerNextEvent, 100);
      },
      triggerNextEvent: function () {
        clientMesh.exchange.event.triggerEvent(message++);
      }
    };
    return serverMesh.stop()
      .then(utils.startTimer)
      .then(utils.waitForOffline)
      .then(utils.waitForTime)
      .then(function () {
        return happner.create(serverConfig);
      })
      .then(function (server) {
        serverMesh = server;
      })
      .then(utils.waitForEvents)
  });

  it('d - should buffer more events than allowed', function () {
    this.timeout(20000);

    var utils = {
      waitForOffline: Promise.promisify(function (result, callback) {
        clientMesh.event.client.on('client/disconnect', function () {
          clientMesh.event.client.off('client/disconnect', callback);
        })
      }),
      waitForTime: Promise.promisify(function (result, callback) {
        setTimeout(callback, 2000);
      }),
      waitForEvents: Promise.promisify(function (result, callback) {
        var messageReceived = [];
        serverMesh.event.server.on('edge/*', function (message, _meta) {
          var messageRec = parseInt(message.value) - 100;
          messageReceived[messageRec] = true;

          if (messageRec == 0) return;
          if (messageReceived[messageRec - 1] !== true) {
            return callback("Messages received out of order " + messageRec);
          }
          if (messageRec == 99) {
            callback();
          }
        }, function () {
        })
      }),
      trigger100Events: function () {
        for (var i = 0; i < 200; i++) {
          clientMesh.exchange.event.triggerEvent(i);
        }

      }
    };
    return serverMesh.stop()
      .then(utils.waitForOffline)
      .then(utils.trigger100Events)
      .then(utils.waitForTime)
      .then(function () {
        return happner.create(serverConfig);
      })
      .then(function (server) {
        serverMesh = server;
      })
      .then(utils.waitForEvents)
  });
});


function getOemAdminGroup() {
  var regesterDeviceMethodPath = "/" + SERVER_MESH_NAME + "/" + SERVER_COMPONENT_NAME + "/registerDevice";

  var oemAdminGroup = {
    name: "OEM Admin",
    permissions: {
      methods: {}
    }
  };

  oemAdminGroup.permissions.methods[regesterDeviceMethodPath] = {authorized: true};

  return oemAdminGroup;
}

var OemUser = {
  username: 'user@oem.com',
  password: 'TEST PWD',
  customData: {
    oem: "OEM A",
    company: "Enterprise X"
  }
};
