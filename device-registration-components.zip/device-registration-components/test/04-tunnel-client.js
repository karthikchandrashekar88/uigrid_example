var should = require('chai').should();
var happner = require('happner');
var path = require('path');
var FstBridgeEmu = require('@smc/fst_bridge_emu');
var async = require('async');
var ownPath = path.join(__dirname, '../index.js');

var TUNNEL_PROXY_HOST = 'tunnel.127.0.0.1.nip.io';
var SERVER_HOST = "127.0.0.1.nip.io";
var SERVER_PORT = 8096;
var CLIENT_PORT = 8097;
var EMU_PORT = 8080;

var SERVER_COMPONENT_NAME = "server";
var SERVER_MESH_NAME = require('shortid').generate();

var DEVICE_KEEPALIVE_INTERVAL = 500;
var TUNNEL_HEALTH_INTERVAL = 5000;
var TUNNEL_SERVICE_ENDPOINT = "ws://127.0.0.1.nip.io:10000";

var eventClientConfig = {
  name: 'event-client',
  port: 6666,
  endpoints: {}
};

eventClientConfig.endpoints[SERVER_MESH_NAME] = {
  config: {
    port: SERVER_PORT,
    host: 'localhost',
    username: '_ADMIN',
    password: 'password'
  }
};

var tunnelClientOpts1 = {};

var tunnelServerOpts = {
  name: 'Tunnel Proxy Server',
  wsport: 10000,
  wshostname: '0.0.0.0',
  forwardingHostname: '0.0.0.0',
  healthInterval: 5000,

  emits: {
    'server/create': true,
    'tunnel/create': true,
    'tunnel/open': true,
    'tunnel/close': true,
    'tunnel/error': true,
    'tunnel/health': true,
    'tunnel/destroy': true,
    'tunnel/reset': true,
    'carrier/create': true,
    'carrier/ready': true,
    'carrier/destroy': true,
    'carrier/fail': true,
    'carrier/connect': true,
    'carrier/buzy': true,
    'carrier/close': true,
    'carrier/available': true,
    'session/error': true
  }
};


var clientConfig = {
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: CLIENT_PORT,
    persist: true,
    defaultRoute: "mem"
  },
  modules: {
    "pe": {
      path: "@smc/pe-component"
    },
    client: {
      path: ownPath,
      create: {
        name: 'Client',
        type: 'sync'
      }
    },
    'tunnel-service': {
      path: '@smc/tunnel-service'
    }
  },
  components: {
    data: {},
    "pe": {
      moduleName: "pe",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {port: EMU_PORT}
              }
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    'tunnel-service': {
      moduleName: 'tunnel-service'
    },
    client: {
      name: "client",
      moduleName: "client",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  serverMeshPort: SERVER_PORT,
                  serverMeshHost: SERVER_HOST,
                  serverComponentName: SERVER_COMPONENT_NAME,
                  protocol: 'http'
                }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      },
      web: {
        routes: {
          web: ["gzip", "checkIndex", "static"]
        }
      },
      data: {
        routes: {
          //'registrationData/*': 'persist'
        }
      }
    }
  }
};


var serverConfig = {
  name: SERVER_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: SERVER_PORT,
    persist: true,
    defaultRoute: "mem",
    middleware: {
      security: {
        cookieName: "FieldPoP.io",
        cookieDomain: '.127.0.0.1.nip.io',
        exclusions: [
          '/*'
        ]
      }
    }
  },
  modules: {
    server: {
      path: ownPath,
      create: {
        name: 'Server',
        type: 'sync'
      }
    },
    'tunnel-service': {
      path: '@smc/tunnel-service'
    },
    'tunnel-proxy': {
      path: '@smc/tunnel-proxy'
    }
  },
  components: {
    data: {},
    server: {
      name: 'server',
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options", "required": true, value: {
                deviceKeepaliveInterval: DEVICE_KEEPALIVE_INTERVAL,
                tunnelHealthInterval: TUNNEL_HEALTH_INTERVAL,
                tunnelServiceEndpoint: TUNNEL_SERVICE_ENDPOINT,
                tunnelProxyHost: TUNNEL_PROXY_HOST
                //tunnelProxyPort: 55000,
                //protocol: 'https'
              }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      }
    },
    'tunnel-service': {
      moduleName: 'tunnel-service',
      startMethod: 'createServer',
      schema: {
        methods: {
          'createServer': {
            parameters: [
              {name: 'opts', value: tunnelServerOpts}
            ]
          }
        }
      },
      web: {
        routes: {
          "static": "dashboard"
        }
      }
    },
    'tunnel-proxy': {
      moduleName: 'tunnel-proxy',
      startMethod: 'start',
      schema: {
        methods: {
          'start': {
            parameters: [{
              name: 'opts',
              value: {
                override: true,
                excludes: ['127.0.0.1.nip.io']
              }
            }]
          }
        }
      }
    }
  }
};

var test_filename = path.basename(__filename);

describe(test_filename, function () {
  var clientMesh;
  var serverMesh;
  var eventClientMesh;

  this.timeout(15000);

  before(function (done) {
    var savedUser = null;
    var savedGroup = null;

    fst_bridge_emu = FstBridgeEmu.emu({httpPort: EMU_PORT});
    fst_bridge_emu.once('online', function () {
      done();
    });
  });

  after(function (done) {
    async.parallel([
        function (cb) {
          if (!fst_bridge_emu) return cb();
          fst_bridge_emu.shutdown(cb);
        },
        function (cb) {
          if (!clientMesh) return cb();
          clientMesh.stop(cb)
        },
        function (cb) {
          if (!serverMesh) return cb();
          serverMesh.stop(cb);
        }],
      done
    );
  });

  it('client should establish tunnel', function (done) {

    var credentials = {
      username: '_ADMIN',
      password: 'password'
    };

    happner.create(serverConfig, function (e, server) {
      serverMesh = server;

      // make new mesh that subscribes to tunnel events
      happner.create(eventClientConfig, function (err, eventClient) {
        eventClientMesh = eventClient;
        if (err) {
          console.log('\nEVENT-CLIENT error :' + err);
          done(err);
        }
        eventClientMesh.event [SERVER_MESH_NAME]['tunnel-service'].on('*', tunnelEventHandler);

        happner.create(clientConfig, function (e, client) {
          clientMesh = client;

          clientMesh.exchange.client.registerDevice(credentials, {
            name: "a",
            description: "b",
            location: '0,0'
          }, function (err) {
          });
        });

        function tunnelEventHandler(data, meta) {
          if (meta.path.match(/tunnel\/create$/)) {
            eventClientMesh.stop(done);
          }
        }
      });
    });

  });

});
