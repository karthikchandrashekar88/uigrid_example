var path = require('path');

var PC = !(process.arch == 'arm');
var DA_COUNT = 2;
var OFFSET_COUNT = 100;
var GET_DA_VALUE_INTERVAL = 1000;
var TEST_DURATION = 60000;

var www_path;

if(PC){
  www_path = path.join(__dirname, '../packageInfo')
}
else{
  www_path = "/fst";
}

var shell = require('shelljs');


//var should = require('chai').should();
var happner = require('happner');

var ownPath = path.join(__dirname, '../index.js');

//var SERVER_HOST = "www.fieldpop.io";
var SERVER_HOST = "192.168.100.234.nip.io";
var SERVER_PORT = 443;
var CLIENT_PORT = 8091;

var MESH_SECRET = "client_config_mesh";
var TUNNEL_CLIENT_MESH_NAME = "client";
var SERVER_COMPONENT_NAME = "server";

var CLIENT_MESH_FILE_NAME = "ae.nedb";
var TUNNEL_FORWARD_ADDRESS = 'localhost:81';

var clientConfig = {
  //name: TUNNEL_CLIENT_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    filename:CLIENT_MESH_FILE_NAME,
    port: CLIENT_PORT,
    persist: true,
    setOptions:{
      timeout:60000
    },
    defaultRoute: "mem",
    middleware:{
      security:{
        exclusions:[
          '/*'
        ]
      }
    }
  },
  modules: {
    //client: {
    //  path: ownPath,
    //  create: {
    //    name: 'Client',
    //    type: 'sync'
    //  }
    //},
    //'tunnel-service': {
    //  path: '@smc/tunnel-service'
    //},
    "fstProxy": {
      path: '@smc/proxy_component',
      constructor: {
        type: "sync",
        parameters: []
      }
    },
    "pe": {
      path: "@smc/pe-component"
    },
    "data_alarms": {
      path: '@smc/data_alarm_component',
      constructor: {
        type: "sync",
        parameters: []
      }
    },
    "data_notifications": {
      path: '@smc/data_notification_component',
      constructor: {
        type: "sync",
        parameters: []
      }
    }
  },
  components: {
    data: {},
    //'tunnel-service': {
    //  moduleName: 'tunnel-service'
    //},
    "pe": {
      moduleName: "pe",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  port: 8080,
                  hostname: '127.0.0.1',
                  enable_da: true,
                  store_enable: true,
                  save_delay_multiplier: 100,
                  get_da_list_period: 30000,
                  get_da_value_period: GET_DA_VALUE_INTERVAL,
                  maximum_publish_delay: 5000
                }
              }
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    data_alarms: {
      moduleName: 'data_alarms',
      scope: 'component',
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [{}]
          },
          "stop": {
            type: "async",
            parameters: [{
              "name": "callback",
              "type": "callback",
              "required": true
            }]
          },
        }
      }
    },
    data_notifications: {
      moduleName: 'data_notifications',
      scope: 'component',
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [{"name": "options", "type": "options", "required": true, "value": {min_notification_interval: 100}}]
          },
          "stop": {
            type: "async",
            parameters: [{
              "name": "callback",
              "type": "callback",
              "required": true
            }]
          }
        }
      }
    },
    //client: {
    //  name: "client",
    //  moduleName: "client",
    //  scope: "component",
    //  startMethod: "start",
    //  stopMethod: "stop",
    //  schema: {
    //    "exclusive": false,
    //    "methods": {
    //      "start": {
    //        type: "async",
    //        parameters: [
    //          {
    //            "name": "options",
    //            "required": true,
    //            value: {
    //              serverMeshPort: SERVER_PORT,
    //              serverMeshHost: SERVER_HOST,
    //              serverComponentName: SERVER_COMPONENT_NAME,
    //              tunnelForwardAddress: TUNNEL_FORWARD_ADDRESS,
    //              protocol:'https',
    //              aeRoot: "/node_js/app",
    //              pe_component: "pe",
    //              alarm_component: "data_alarms"
    //            }
    //          }
    //        ]
    //      },
    //      "stop": {
    //        type: "sync"
    //      }
    //    }
    //  },
    //  web: {
    //    routes: {
    //      web: ["gzip", "checkIndex", "static"],
    //      config: ["checkIndex", "multipart", "update_config", "static"]
    //    }
    //  },
    //  data: {
    //    routes:{
    //      deviceData : 'persist',
    //      remoteEventCache: 'persist'
    //    }
    //  }
    //},
    "www": {
      moduleName: "fstProxy",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        exclusive: true,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {name: 'options', required: true, value: {staticRoot: www_path, port: 8080}},
              {type: 'callback', required: true}
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
  }
};


var mesh;

console.log("=-= Launching FieldPoP Client =-=");

if(PC) {
  var FstBridgeEmu = require('@smc/fst_bridge_emu');
  var emu_path = path.join(__dirname, '../packageInfo');
  fst_bridge_emu = FstBridgeEmu.emu({port: 8080, working_dir: emu_path});

  fst_bridge_emu.on('online', function () {
    start_mesh();
  });
}
else{
  start_mesh();
}



function start_mesh(){
  happner.create(clientConfig, function (e, client) {
    if (e) return console.log(e);
    mesh = client;
    console.log('\ncreated Client\n\n');

    mesh.exchange.data_notifications.getEnums(function(err, enums){
      if(err) return console.log(err);
      setupNotificationSubs(enums);
    })
  });
}



var n_count = 0;
var val_count = 0;
var n_id_count = {};

function setupNotificationSubs(Enums){

  console.log("Setup Notification Subs");
  mesh.event.data.on("pe/data_arrays/*", notificationHandler, function(err){
    if(err) console.log(err);

    setTimeout(function(){
      console.log(n_id_count);
      mesh.log.info("--------END--------");

      mesh.exchange.pe.stop();
      //mesh.event.data.off("pe/data_arrays/*", function(err){
      //  if(err) console.log(err);
      //  console.log(n_id_count);
      //  console.log("--------END--------");
      //
      //})
    }, TEST_DURATION)
  })
}


function notificationHandler(message, _meta){
  n_count++;

  delete message._meta

  var vals = Object.keys(message);

  vals.forEach(function(id){
    if(n_id_count[id]){
      n_id_count[id]++
    }
    else{
      n_id_count[id] = 1;
    }
  })

  val_count += vals.length;

  mesh.log.info("Notifications: %s, Values: %s", n_count, val_count );
};