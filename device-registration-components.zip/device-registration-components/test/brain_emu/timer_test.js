
var dates = [];

for (var i = 0; i < 10000; i++){
    var d = new Date().getTime();
    dates.push(d);
}

console.log(dates[0], dates[999], (dates[999] - dates[0]));