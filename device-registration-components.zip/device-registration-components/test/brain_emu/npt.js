var path = require('path');
var argv = require('optimist').argv;


var PC = !(process.arch == 'arm');
var DA_COUNT =  argv.daCount || 1;
var OFFSET_COUNT = argv.offsetCount || 1000;
var GET_DA_VALUE_INTERVAL = argv.daInterval || 5000;
var MAX_PUB_DELAY = GET_DA_VALUE_INTERVAL;
var MIN_NOTIFICATION_INTERVAL = 100;
var PERIODIC_NOTIFICATION = GET_DA_VALUE_INTERVAL/1000;
var TEST_DURATION = argv.testDuration || 60000;
var AFTER_TEST_TIMEOUT = argv.afterTestTiemout ||  15000;


var www_path;

if(PC){
  www_path = path.join(__dirname, '../packageInfo')
}
else{
  www_path = "/fst";
}

var shell = require('shelljs');


//var should = require('chai').should();
var happner = require('happner');

var ownPath = path.join(__dirname, '../index.js');

//var SERVER_HOST = "www.fieldpop.io";
var SERVER_HOST = "192.168.100.234.nip.io";
var SERVER_PORT = 443;
var CLIENT_PORT = 8091;

var MESH_SECRET = "client_config_mesh";
var TUNNEL_CLIENT_MESH_NAME = "client";
var SERVER_COMPONENT_NAME = "server";

var CLIENT_MESH_FILE_NAME = "ae.nedb";
var TUNNEL_FORWARD_ADDRESS = 'localhost:81';

var clientConfig = {
  //name: TUNNEL_CLIENT_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    filename:CLIENT_MESH_FILE_NAME,
    port: CLIENT_PORT,
    persist: true,
    setOptions:{
      timeout:60000
    },
    defaultRoute: "mem",
    middleware:{
      security:{
        exclusions:[
          '/*'
        ]
      }
    }
  },
  modules: {
    //client: {
    //  path: ownPath,
    //  create: {
    //    name: 'Client',
    //    type: 'sync'
    //  }
    //},
    //'tunnel-service': {
    //  path: '@smc/tunnel-service'
    //},
    "fstProxy": {
      path: '@smc/proxy_component',
      constructor: {
        type: "sync",
        parameters: []
      }
    },
    "pe": {
      path: "@smc/pe-component"
    },
    "data_alarms": {
      path: '@smc/data_alarm_component',
      constructor: {
        type: "sync",
        parameters: []
      }
    },
    "data_notifications": {
      path: '@smc/data_notification_component',
      constructor: {
        type: "sync",
        parameters: []
      }
    }
  },
  components: {
    data: {},
    //'tunnel-service': {
    //  moduleName: 'tunnel-service'
    //},
    "pe": {
      moduleName: "pe",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  port: 8080,
                  hostname: '127.0.0.1',
                  enable_da: true,
                  store_enable: true,
                  save_delay_multiplier: 1000,
                  get_da_list_period: 300000,
                  get_da_value_period: GET_DA_VALUE_INTERVAL,
                  maximum_publish_delay: MAX_PUB_DELAY
                }
              }
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    data_alarms: {
      moduleName: 'data_alarms',
      scope: 'component',
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [{}]
          },
          "stop": {
            type: "async",
            parameters: [{
              "name": "callback",
              "type": "callback",
              "required": true
            }]
          },
        }
      }
    },
    data_notifications: {
      moduleName: 'data_notifications',
      scope: 'component',
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [{"name": "options", "type": "options", "required": true, "value": {min_notification_interval: MIN_NOTIFICATION_INTERVAL}}]
          },
          "stop": {
            type: "async",
            parameters: [{
              "name": "callback",
              "type": "callback",
              "required": true
            }]
          }
        }
      }
    },
    //client: {
    //  name: "client",
    //  moduleName: "client",
    //  scope: "component",
    //  startMethod: "start",
    //  stopMethod: "stop",
    //  schema: {
    //    "exclusive": false,
    //    "methods": {
    //      "start": {
    //        type: "async",
    //        parameters: [
    //          {
    //            "name": "options",
    //            "required": true,
    //            value: {
    //              serverMeshPort: SERVER_PORT,
    //              serverMeshHost: SERVER_HOST,
    //              serverComponentName: SERVER_COMPONENT_NAME,
    //              tunnelForwardAddress: TUNNEL_FORWARD_ADDRESS,
    //              protocol:'https',
    //              aeRoot: "/node_js/app",
    //              pe_component: "pe",
    //              alarm_component: "data_alarms"
    //            }
    //          }
    //        ]
    //      },
    //      "stop": {
    //        type: "sync"
    //      }
    //    }
    //  },
    //  web: {
    //    routes: {
    //      web: ["gzip", "checkIndex", "static"],
    //      config: ["checkIndex", "multipart", "update_config", "static"]
    //    }
    //  },
    //  data: {
    //    routes:{
    //      deviceData : 'persist',
    //      remoteEventCache: 'persist'
    //    }
    //  }
    //},
    "www": {
      moduleName: "fstProxy",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        exclusive: true,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {name: 'options', required: true, value: {staticRoot: www_path, port: 8080}},
              {type: 'callback', required: true}
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
  }
};


var mesh;

console.log("=-= Launching FieldPoP Client =-=");

if(PC) {
  var FstBridgeEmu = require('@smc/fst_bridge_emu');
  var emu_path = path.join(__dirname, '../packageInfo');
  fst_bridge_emu = FstBridgeEmu.emu({port: 8080, working_dir: emu_path});

  fst_bridge_emu.on('online', function () {
    start_mesh();
  });
}
else{
start_mesh();
}



var n_count = 0;
var val_count = 0;
var n_id_count = {};
var first_event = true;

var time_test_start = null;
var time_test_end = null;
var time_first_event = null;
var time_start_subs = null;
var val_count_at_end = 0;
var event_count_at_end = 0;


function start_mesh(){
  happner.create(clientConfig, function (e, client) {
    if (e) return console.log(e);
    mesh = client;
    console.log('\ncreated Client\n\n');

    n_count = 0;
    val_count = 0;
    n_id_count = {};
    first_event = true;

    time_test_start = null;
    time_test_end = null;
    time_first_event = null;
    time_start_subs = null;
    val_count_at_end = 0;
    event_count_at_end = 0;

    mesh.exchange.data_notifications.getEnums(function(err, enums){
      if(err) return console.log(err);
      setupNotificationSubs(enums);
    })
  });
}



function setupNotificationSubs(Enums){

  //var command  = './watch_node.sh';
  //shell.exec(command, {silent:true}, function (code, output) {
  //  console.log(output);
  //});

  time_start_subs = new Date().getTime();

  console.log("Setup Notification Subs");
  mesh.event.data_notifications.on("data_notification", notificationHandler, function(err){
    if(err) console.log(err);
  })



  for(var j = 0; j < DA_COUNT; j++){
    mesh.log.$$DEBUG("Create sub for DA_0" + j  + ", offset count: " + OFFSET_COUNT);
    for(var i = 0; i < OFFSET_COUNT; i++){
      var test_monitor_point = {
        notification_id: 'DA_0' + j + '_' + i,
        mesh_path: 'pe/data_arrays/DA_0' + j,
        property: i,
        component: "data",
        notification_type: Enums.notificationType.PERIODIC,
        periodic_interval: PERIODIC_NOTIFICATION,
        notification_condition: Enums.notificationConditions.ALWAYS
      };

      mesh.log.$$DEBUG("Add Point", test_monitor_point.notification_id, test_monitor_point.mesh_path, test_monitor_point.property);

      mesh.exchange.data_notifications.addMonitorPoint(test_monitor_point, function (err, data) {
        if(err) return console.log(err);
      });
    }
  }
  time_test_start = new Date().getTime();
  console.log("Sub Complete");
}

function start_test_timer(){
  setTimeout(function(){
      //console.log(n_id_count);
      console.log("--------END--------");
      time_test_end = new Date().getTime();

      val_count_at_end = val_count;
      event_count_at_end = n_count;

      for(var j = 0; j < DA_COUNT; j++){
        for(var i = 0; i < OFFSET_COUNT; i++){
          var notification_id= 'DA_0' + j + '_' + i;

          mesh.exchange.data_notifications.removeMonitorPoint(notification_id, function (err, data) {
            if(err) return console.log(err);
          });
        }
      }

      setTimeout(analyze_performance, AFTER_TEST_TIMEOUT)

    }, TEST_DURATION);
}

function analyze_performance(){

  console.log("\nTest duration: %d", TEST_DURATION);
  console.log("get_da_value = maximum_publish = periodic_interval: %d", GET_DA_VALUE_INTERVAL);
  console.log("min_notification: %d", MIN_NOTIFICATION_INTERVAL);

  console.log("DA offset count: %d", OFFSET_COUNT);
  console.log("DA count: %d", DA_COUNT);
  console.log("subsription count :%d", DA_COUNT * OFFSET_COUNT);
  console.log("subsription time :%dms",  time_test_start - time_start_subs);


  console.log("\nInitial Event Delay: %dms", time_first_event - time_test_start);

  console.log("\nExpected event count: %d", TEST_DURATION/GET_DA_VALUE_INTERVAL);
  console.log("Expected value count: %d", (TEST_DURATION/GET_DA_VALUE_INTERVAL) * DA_COUNT * OFFSET_COUNT);

  console.log("\nEvent count at END: %d", event_count_at_end);
  console.log("Value count at END: %d", val_count_at_end);

  console.log("\nEvents after END: %d", n_count - event_count_at_end);
  console.log("Values after END: %d\n\n", val_count - val_count_at_end);

  if(PC) {
    fst_bridge_emu.shutdown(function(){
      mesh.stop(function(){
        process.exit();
      });
    });
  }
  else{
    process.exit();
  }

}



function notificationHandler(message, _meta){

  if(first_event==true){
    first_event = false;
    time_first_event = new Date().getTime();
    start_test_timer();
  }

  n_count++;

  delete message._meta

  //var vals = Object.keys(message);
  //
  //vals.forEach(function(id){
  //  if(n_id_count[id]){
  //    n_id_count[id]++
  //  }
  //  else{
  //    n_id_count[id] = 1;
  //  }
  //})

  console.log(message);
  val_count += message.value;//vals.length;

  mesh.log.info("Notifications: %s, Values: %s", n_count, val_count );
};