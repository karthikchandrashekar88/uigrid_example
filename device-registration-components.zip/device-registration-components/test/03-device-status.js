var should = require('chai').should();
var happner = require('happner');
var path = require('path');
var FstBridgeEmu = require('@smc/fst_bridge_emu');
var async = require('async');
var ownPath = path.join(__dirname, '../index.js');

var SERVER_HOST = "localhost";
var SERVER_PORT = 8094;
var CLIENT_PORT = 8095;

var EMU_PORT = 8080;

var SERVER_COMPONENT_NAME = "server";
var SERVER_MESH_NAME = require('shortid').generate();

var DEVICE_KEEPALIVE_INTERVAL = 500;
var TUNNEL_HEALTH_INTERVAL = 5000;
var TUNNEL_SERVICE_ENDPOINT = "ws://192.168.1.5:8000";

var clientConfig = {
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: CLIENT_PORT,
    persist: true,
    defaultRoute: "mem"
  },
  modules: {
    "pe": {
      path: "@smc/pe-component"
    },
    client: {
      path: ownPath,
      create: {
        name: 'Client',
        type: 'sync'
      }
    }
  },
  components: {
    data: {},
    "pe": {
      moduleName: "pe",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {port: EMU_PORT}
              }
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    client: {
      name: "client",
      moduleName: "client",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  serverMeshPort: SERVER_PORT,
                  serverMeshHost: SERVER_HOST,
                  serverComponentName: SERVER_COMPONENT_NAME,
                  peRoot: path.join(__dirname, "packageInfo"),
                  aeRoot: path.join(__dirname, "../"),
                  protocol: 'http'
                }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      },
      web: {
        routes: {
          web: ["gzip", "checkIndex", "static"]
        }
      },
      data: {
        routes: {
          //'registrationData/*': 'persist'
        }
      }
    }
  }
};


var serverConfig = {
  name: SERVER_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: SERVER_PORT,
    persist: true,
    defaultRoute: 'mem'
  },
  modules: {
    server: {
      path: ownPath,
      create: {
        name: 'Server',
        type: 'sync'
      }
    }
  },
  components: {
    data: {},
    server: {
      name: "server",
      moduleName: "server",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options", "required": true, value: {
                deviceKeepaliveInterval: DEVICE_KEEPALIVE_INTERVAL,
                tunnelHealthInterval: TUNNEL_HEALTH_INTERVAL,
                tunnelServiceEndpoint: TUNNEL_SERVICE_ENDPOINT
              }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      }
    }
  }
};

var test_filename = path.basename(__filename);

describe(test_filename, function () {
  var clientMesh;
  var serverMesh;
  var fst_bridge_emu;

  this.timeout(20000);

  before(function (done) {
    var savedUser = null;
    var savedGroup = null;

    fst_bridge_emu = FstBridgeEmu.emu({httpPort: EMU_PORT});
    fst_bridge_emu.on('online', function () {
      happner.create(serverConfig)
        .then(addGroup)
        .then(addUser)
        .then(linkUser)
        .then(createClient)
        .then(saveClient)
        .catch(function (err) {
          done(err);
        });
    });


    function addGroup(server) {
      serverMesh = server;
      return serverMesh.exchange.security.addGroup(getOemAdminGroup());
    }

    function addUser(group) {
      savedGroup = group;
      return serverMesh.exchange.security.addUser(OemUser);
    }

    function linkUser(user) {
      savedUser = user;
      return serverMesh.exchange.security.linkGroup(savedGroup, savedUser);
    }

    function createClient() {
      return happner.create(clientConfig);
    }

    function saveClient(client) {
      clientMesh = client;
      done();
    }
  });

  after(function (done) {
    async.parallel([
        function (cb) {
          if (!fst_bridge_emu) return cb();
          fst_bridge_emu.shutdown(cb);
        },
        function (cb) {
          if (!clientMesh) return cb();
          var shuttingDown = true;
          clientMesh.stop(function () {
            clientMesh = undefined;
            if (shuttingDown) {
              shuttingDown = false;
              console.log('INFO: clientMesh shut down normally');
              cb();
            }
          });
          setTimeout(function catchBadShutdown() {
            if (shuttingDown) {
              shuttingDown = false;
              console.log('WARNING: clientMesh did not shut down, ignoring');
              cb();
            }
          }, 5000);
        },
        function (cb) {
          if (!serverMesh) return cb();
          serverMesh.stop(cb);
        }],
      done
    );
  });

  it('a - client should register a device on the server', function (done) {
    var status_count = 0;
    this.timeout(50000);
    var client_device_id = null;
    var kill_client = false;


    serverMesh.event.server.on("deviceRegistered/*", handleDeviceRegistrationEvent, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    serverMesh.event[SERVER_COMPONENT_NAME].on("deviceStatus/*", handleStatusEvent, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    var deviceDetails = {
      description: "FieldPoP test device",
      location: "Somewhere east of somewhere",
      name: "Test device 1"
    };

    clientMesh.exchange.client.registerDevice(OemUser, deviceDetails, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    function handleDeviceRegistrationEvent(message) {
      message.should.property("deviceId");
      client_device_id = message.deviceId;
      serverMesh.event.server.off("deviceRegistered/*", function (err) {
        if (err) console.log(err);
        should.not.exist(err);
      });
    }

    function handleStatusEvent(message, meta) {
      message.deviceId.should.eql(client_device_id);
      message.should.property("name");
      message.should.property("description", deviceDetails.description);
      message.should.property("location", deviceDetails.location);
      message.should.property("name", deviceDetails.name);
      message.should.property("packageInfo");
      message.packageInfo.should.property("productName", "fieldpop_test");
      message.packageInfo.should.property("customerName", "SMC");
      message.packageInfo.should.property("productVersion", "1.0.0");
      message.packageInfo.should.property("moduleVersions");
      message.packageInfo.moduleVersions.should.property("os");
      message.packageInfo.moduleVersions.should.property("pe");

      message.packageInfo.moduleVersions.pe.should.property("Build_Revision");
      message.packageInfo.moduleVersions.pe.Build_Revision.should.not.eql("unknown");

      message.packageInfo.moduleVersions.pe.should.property("Driver_Configuration");
      message.packageInfo.moduleVersions.pe.Driver_Configuration.should.not.eql("unknown");

      message.packageInfo.moduleVersions.pe.should.property("FieldServer_Model");
      message.packageInfo.moduleVersions.pe.FieldServer_Model.should.not.eql("unknown");

      message.packageInfo.moduleVersions.pe.should.property("Carrier_Type");
      message.packageInfo.moduleVersions.should.property("ae");
      message.packageInfo.moduleVersions.ae.should.property("name", "@smc/device-registration-components");
      message.packageInfo.moduleVersions.ae.should.property("version");
      message.packageInfo.moduleVersions.should.property("fsweb");
      message.packageInfo.moduleVersions.fsweb.should.property("name", "web_default");
      message.packageInfo.moduleVersions.fsweb.should.property("version", "70fe82e-dirty");

      if (message.deviceOnline === true && kill_client === false) {
        kill_client = true;
        checkDeviceData();
      }

      if (kill_client === true && message.deviceOnline === false) {
        handleDeviceOffline(message);
      }
    }

    function checkDeviceData() {
      serverMesh.exchange.data.get("deviceStatus/*", function (err, data) {
        var device_found = false;
        for (var i = 0; i < data.length; i++) {
          if (data[i].deviceId === client_device_id) {
            device_found = true;
            if (data[i].deviceOnline == true) {
              clientMesh.stop(function (e) {
                should.not.exist(e);
              });
              break;
            }
          }
        }
        device_found.should.eql(true);
      });
    }

    function handleDeviceOffline(message) {
      message.deviceId.should.eql(client_device_id);

      serverMesh.event[SERVER_COMPONENT_NAME].off("deviceStatus/*", function (err) {
        if (err) console.log(err);
        should.not.exist(err);
        done();
      });
    }
  });
});


function getOemAdminGroup() {
  var regesterDeviceMethodPath = "/" + SERVER_MESH_NAME + "/" + SERVER_COMPONENT_NAME + "/registerDevice";

  var oemAdminGroup = {
    name: "OEM Admin",
    permissions: {
      methods: {}
    }
  };

  oemAdminGroup.permissions.methods[regesterDeviceMethodPath] = {authorized: true};

  return oemAdminGroup;
}

var OemUser = {
  username: 'user@oem.com',
  password: 'TEST PWD',
  customData: {
    oem: "OEM A",
    company: "Enterprise X"
  }
};
