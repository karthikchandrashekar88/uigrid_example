//var should = require('chai').should();
var happner = require('happner');
var path = require('path');

var ownPath = path.join(__dirname, '../../index.js');

//var SERVER_HOST = "smc.fieldpop.io";
var SERVER_HOST = "192.168.100.225";
var SERVER_PORT = 55000;
var CLIENT_PORT = 8091;

var DEVICE_KEEPALIVE_INTERVAL = 10000;
var TUNNEL_HEALTH_INTERVAL = 5000;
var TUNNEL_FORWARD_ADDRESS = 'localhost:8091';


var TUNNEL_PROXY_IP_ADDRESS = SERVER_HOST;
var TUNNEL_PROXY_IP_PORT = 8080;

var TUNNEL_CLIENT_MESH_NAME = "client_mesh";

var MESH_SECRET = "client_config_mesh";

var SERVER_COMPONENT_NAME = "server";
var SERVER_MESH_NAME = "server_mesh_emu";

var DEVICE_KEEPALIVE_INTERVAL = 10000;
var TUNNEL_HEALTH_INTERVAL = 5000;
var TUNNEL_SERVICE_ENDPOINT = "ws://192.168.100.225:8000";

var TUNNEL_PROXY_HOST= "127.0.0.1.nip.io";
var TUNNEL_PROXY_PORT= 8080;

var tunnelServerOpts = {
  name: 'Tunnel Proxy Server',
  wsport: 10000,
  wshostname: '0.0.0.0',
  forwardingHostname: '0.0.0.0',
  healthInterval: 5000,

  emits: {
    'server/create': true,
    'tunnel/create': true,
    'tunnel/open': true,
    'tunnel/close': true,
    'tunnel/error': true,
    'tunnel/health': true,
    'tunnel/destroy': true,
    'tunnel/reset': true,
    'carrier/create': true,
    'carrier/ready': true,
    'carrier/destroy': true,
    'carrier/fail': true,
    'carrier/connect': true,
    'carrier/buzy': true,
    'carrier/close': true,
    'carrier/available': true,
    'session/error': true
  }
};


var clientConfig = {
  name: TUNNEL_CLIENT_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: CLIENT_PORT,
    persist: true,
    defaultRoute: "mem",
    middleware:{
      security:{
        exclusions:[
          '/*'
        ]
      }
    }
  },
  modules: {
    client: {
      path: ownPath,
      create: {
        name: 'Client',
        type: 'sync'
      }
    },
    'tunnel-service': {
      path: '@smc/tunnel-service'
    },
    "fstProxy": {
      path: '@smc/proxy_component',
      constructor: {
        type: "sync",
        parameters: []
      }
    }
  },
  components: {
    "www": {
      moduleName: "fstProxy",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        exclusive: true,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {name: 'options', required: true, value: {staticRoot: path.join(__dirname,'../../fst_emu'), host:'192.168.100.119', port: 80}},
              {type: 'callback', required: true}
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    data: {},
    'tunnel-service': {
      moduleName: 'tunnel-service',
      //startMethod: 'createClient',
      schema: {

      }
    },
    client: {
      name: "client",
      moduleName: "client",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  serverMeshPort: SERVER_PORT,
                  serverMeshHost: SERVER_HOST,
                  serverComponentName: SERVER_COMPONENT_NAME,
                  tunnelForwardAddress: TUNNEL_FORWARD_ADDRESS
                }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      },
      web: {
        routes: {
          web: ["gzip", "checkIndex", "static"],
          config: ["checkIndex", "multipart", "update_config", "static"]
        }
      },
      data: {
        routes:{
          deviceData : 'persist'
        }
      }
    }
  }
};


var serverConfig = {
  name: SERVER_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: SERVER_PORT,
    persist: true,
    defaultRoute: "persist"
  },
  modules: {
    server: {
      path: ownPath,
      create: {
        name: 'Server',
        type: 'sync'
      }
    },
    'tunnel-service': {
      path: '@smc/tunnel-service'
    },
    'tunnel-proxy': {
      path: '@smc/tunnel-proxy'
    }
  },
  components: {
    data:{},
    server: {
      name: 'server',
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options", "required": true, value: {
                deviceKeepaliveInterval: DEVICE_KEEPALIVE_INTERVAL,
                tunnelHealthInterval: TUNNEL_HEALTH_INTERVAL,
                tunnelServiceEndpoint: TUNNEL_SERVICE_ENDPOINT,
                tunnelProxyHost: TUNNEL_PROXY_HOST,
                tunnelProxyPort: TUNNEL_PROXY_PORT
              }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      }
    },
    'tunnel-service': {
      moduleName: 'tunnel-service',
      startMethod: 'createServer',
      schema: {
        methods: {
          'createServer': {
            parameters: [
              {name: 'opts', value: tunnelServerOpts}
            ]
          }
        }
      },
      web: {
        routes: {
          "static": "dashboard"
        }
      }
    },
    'tunnel-proxy': {
      moduleName: 'tunnel-proxy',
      startMethod: 'start',
      schema: {
        methods: {
          'start': {
            parameters: [{
              name: 'opts',
              value: {
                listenPort: TUNNEL_PROXY_IP_PORT
              }
            }]
          }
        }
      }
    }
  }
};


var clientMesh;
var serverMesh;

function createClient() {
  happner.create(clientConfig, function (e, client) {
    if (e) return console.log(e);
    clientMesh = client;
    console.log('\ncreated Client\n\n');
  });
}


happner.create(serverConfig)
    //.then(addGroup)
    //.then(addUser)
    //.then(linkUser)
    .then(createClient)
    .catch(function (err) {
      console.log("Create Error", err);
    });

function addGroup(server) {
  serverMesh = server;
  console.log('\ncreated Server\n\n');
  return serverMesh.exchange.security.addGroup(getOemAdminGroup());
}

function addUser(group) {
  savedGroup = group;
  console.log('\ncreated getOemAdminGroup');
  return serverMesh.exchange.security.addUser(OemUser);
}

function linkUser(user) {
  savedUser = user;
  return serverMesh.exchange.security.linkGroup(savedGroup, savedUser);
}

function getOemAdminGroup() {
  var regesterDeviceMethodPath = "/" + SERVER_MESH_NAME + "/" + SERVER_COMPONENT_NAME + "/registerDevice";

  var oemAdminGroup = {
    name: "OEM Admin",
    permissions: {
      methods: {}
    }
  };

  oemAdminGroup.permissions.methods[regesterDeviceMethodPath] = {authorized: true};

  return oemAdminGroup;
}

var OemUser = {
  username: 'user@oem.com',
  password: 'TEST PWD'
};
