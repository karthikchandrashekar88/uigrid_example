//var should = require('chai').should();
var happner = require('happner');
var path = require('path');
var ip = require('ip');


var ownPath = path.join(__dirname, '../../index.js');

var SERVER_PORT = 55000;

var MESH_SECRET = "client_config_mesh";

var SERVER_COMPONENT_NAME = "server";
var SERVER_MESH_NAME = "server_only_mesh";
var SERVER_DB_FILE_NAME = path.join(process.cwd(), "./server.nedb");

var DEVICE_KEEPALIVE_INTERVAL = 10000;
var TUNNEL_HEALTH_INTERVAL = 5000;

var MY_IP = ip.address();
var TUNNEL_PROXY_HOST = MY_IP + ".nip.io";
var TUNNEL_PROXY_PORT= 8081;

var TUNNEL_SERVICE_PORT = 10000;
var TUNNEL_SERVICE_ENDPOINT = 'ws://' + TUNNEL_PROXY_HOST + ':' + TUNNEL_SERVICE_PORT;


var OemUser = {
  username: 'user@oem.com',
  password: 'TEST_PWD'
};



var tunnelServerOpts = {
  name: 'Tunnel Proxy Server',
  wsport: 10000,
  wshostname: '0.0.0.0',
  forwardingHostname: '0.0.0.0',
  healthInterval: 5000,

  emits: {
    'server/create': true,
    'tunnel/create': true,
    'tunnel/open': true,
    'tunnel/close': true,
    'tunnel/error': true,
    'tunnel/health': true,
    'tunnel/destroy': true,
    'tunnel/reset': true,
    'carrier/create': true,
    'carrier/ready': true,
    'carrier/destroy': true,
    'carrier/fail': true,
    'carrier/connect': true,
    'carrier/buzy': true,
    'carrier/close': true,
    'carrier/available': true,
    'session/error': true
  }
};



var serverConfig = {
  name: SERVER_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: SERVER_PORT,
    filename: SERVER_DB_FILE_NAME,
    persist: true,
    defaultRoute: "persist",
    middleware:{
      security:{
        exclusions:[
          '/*'
        ]
      }
    }
  },
  modules: {
    server: {
      path: ownPath,
      create: {
        name: 'Server',
        type: 'sync'
      }
    },
    'tunnel-service': {
      path: '@smc/tunnel-service'
    },
    'tunnel-proxy': {
      path: '@smc/tunnel-proxy'
    },
    'fstProxy': {
      path: '@smc/proxy_component'
    }
  },
  components: {
    data: {},
    server: {
      name: 'server',
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options", "required": true, value: {
                deviceKeepaliveInterval: DEVICE_KEEPALIVE_INTERVAL,
                tunnelHealthInterval: TUNNEL_HEALTH_INTERVAL,
                tunnelServiceEndpoint: TUNNEL_SERVICE_ENDPOINT,
                tunnelProxyHost: TUNNEL_PROXY_HOST,
                tunnelProxyPort: TUNNEL_PROXY_PORT,
                protocol: 'http'
              }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      }
    },
    'tunnel-service': {
      moduleName: 'tunnel-service',
      startMethod: 'createServer',
      schema: {
        methods: {
          'createServer': {
            parameters: [
              {name: 'opts', value: tunnelServerOpts}
            ]
          }
        }
      },
      web: {
        routes: {
          "static": "dashboard"
        }
      }
    },
    'tunnel-proxy': {
      moduleName: 'tunnel-proxy',
      startMethod: 'start',
      accessLevel: 'mesh',
      schema: {
        methods: {
          'start': {
            parameters: [{
              name: 'opts',
              value: {
                override: true,
                excludes: [MY_IP + ".nip.io"]
              }
            }]
          }
        }
      }
    },
    "www": {
      moduleName: "fstProxy",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        exclusive: true,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                name: 'options',
                required: true,
                value: {staticRoot: path.join(process.cwd(), './test/packageInfo'), host: '127.0.0.1', port: SERVER_PORT}
              },
              {type: 'callback', required: true}
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    }
  }
};


var serverMesh;
var savedGroup;
var savedUser;

happner.create(serverConfig)
    .then(addGroup)
    .then(addUser)
    .then(linkUser)
    .catch(function (err) {
      console.log("Create Error",err);
    });

function addGroup(server) {
  serverMesh = server;
  console.log('\ncreated Server\n\n');
  serverMesh.exchange.security

  return serverMesh.exchange.security.updateGroup(getOemAdminGroup());
}

function addUser(group) {
  savedGroup = group;
  console.log('\ncreated getOemAdminGroup');
  return serverMesh.exchange.security.updateUser(OemUser);
}

function linkUser(user) {
  savedUser = user;
  return serverMesh.exchange.security.linkGroup(savedGroup, savedUser);
}

function getOemAdminGroup() {
  var regesterDeviceMethodPath = "/" + SERVER_MESH_NAME + "/" + SERVER_COMPONENT_NAME + "/registerDevice";

  var oemAdminGroup = {
    name: "OEM Admin",
    permissions: {
      methods: {}
    }
  };

  oemAdminGroup.permissions.methods[regesterDeviceMethodPath] = {authorized: true};
  return oemAdminGroup;
}

