//var should = require('chai').should();
var happner = require('happner');
var path = require('path');
var FstBridgeEmu = require('@smc/fst_bridge_emu');

var ownPath = path.join(__dirname, '../../index.js');
var emu_path = path.join(__dirname, '../packageInfo');
var SERVER_HOST = "smc.fieldpop.io";

var SERVER_PORT = 443;
var MESH_PORT = 8091;

var PE_PORT = 8080;

var MESH_SECRET = "client_config_mesh";

var SERVER_COMPONENT_NAME = "server";

var DEVICE_KEEPALIVE_INTERVAL = 10000;
var TUNNEL_CLIENT_MESH_NAME = "emu_client_mesh";
var CLIENT_MESH_FILE_NAME = "smc_client_mesh.nedb";

var TUNNEL_FORWARD_ADDRESS = 'localhost:8091';
var GET_DA_VALUE_INTERVAL = DEVICE_KEEPALIVE_INTERVAL;


var clientConfig = {
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    filename: CLIENT_MESH_FILE_NAME,
    port: MESH_PORT,
    persist: true,
    setOptions: {
      timeout: 30000
    },
    defaultRoute: "mem",
    middleware: {
      security: {
        exclusions: [
          '/*'
        ]
      }
    }
  },
  modules: {
    fieldpopClient: {
      path: ownPath,
      create: {
        name: 'Client',
        type: 'sync'
      }
    },
    'tunnel-service': {
      path: '@smc/tunnel-service'
    },
    "fstProxy": {
      path: '@smc/proxy_component',
      constructor: {
        type: "sync",
        parameters: []
      }
    },
    "pe": {
      path: "@smc/pe-component"
    },
    "data_alarms": {
      path: '@smc/data_alarm_component',
      constructor: {
        type: "sync",
        parameters: []
      }
    }
  },
  components: {
    data: {},
    'tunnel-service': {
      moduleName: 'tunnel-service'
    },
    "pe": {
      moduleName: "pe",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  port: MESH_PORT,
                  hostname: '127.0.0.1',
                  enable_da: true,
                  store_enable: true,
                  save_delay_multiplier: 100,
                  get_da_list_period: 15000,
                  get_da_value_period: GET_DA_VALUE_INTERVAL
                }
              }
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    data_alarms: {
      moduleName: 'data_alarms',
      scope: 'component',
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [{}]
          },
          "stop": {
            type: "async",
            parameters: [{
              "name": "callback",
              "type": "callback",
              "required": true
            }]
          }
        }
      }
    },
    fieldpop: {
      name: "emu_client",
      moduleName: "fieldpopClient",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  serverMeshPort: SERVER_PORT,
                  serverMeshHost: SERVER_HOST,
                  serverComponentName: SERVER_COMPONENT_NAME,
                  tunnelForwardAddress: TUNNEL_FORWARD_ADDRESS,
                  protocol: 'https',
                  peRoot: path.join(__dirname, "../packageInfo"),
                  aeRoot: path.join(__dirname, "../packageInfo"),
                  pe_component: "pe",
                  alarm_component: "data_alarms",
                  fieldpop_mgr: "fieldpop_user_mgr",
                  pe_port: PE_PORT
                }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      },
      web: {
        routes: {
          client: ["gzip", "checkIndex", "static"],
          config: ["checkIndex", "multipart", "update_config", "static"]
        }
      },
      data: {
        routes:{
          deviceData : 'persist',
          fieldpop : 'persist',
          remoteEventCache: 'persist'
        }
      }
    },
    "www": {
      moduleName: "fstProxy",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        exclusive: true,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                name: 'options',
                required: true,
                value: {staticRoot: emu_path, host: '127.0.0.1', port: PE_PORT}
              },
              {type: 'callback', required: true}
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    }
  }
};


var clientMesh;
FstBridgeEmu.emu.killall(function () {
  fst_bridge_emu = FstBridgeEmu.emu({port: PE_PORT, working_dir: emu_path});

  fst_bridge_emu.once('online', function () {
    start_mesh();
  });
});

function start_mesh() {
  happner.create(clientConfig, function (e, client) {
    if (e) return console.log(e);
    clientMesh = client;
    console.log('\ncreated Client\n\n');
  });
}
