var should = require('chai').should();
var happner = require('happner');
var path = require('path');
var FstBridgeEmu = require('@smc/fst_bridge_emu');
var fs = require('fs');
var shortid = require('shortid');
var async = require('async');
var ownPath = path.join(__dirname, '../index.js');

var SERVER_HOST = "localhost";
var SERVER_PORT = 8104;
var CLIENT_PORT = 8105;
var EMU_PORT = 8080;
var SERVER_COMPONENT_NAME = "server";
var SERVER_MESH_NAME = shortid.generate();
var CLIENT_MESH_NAME = 'client';

var DEVICE_KEEPALIVE_INTERVAL = 500;
var TUNNEL_HEALTH_INTERVAL = 5000;
var TUNNEL_SERVICE_ENDPOINT = "ws://192.168.1.5:8000";


var clientConfig = {
  name: CLIENT_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: CLIENT_PORT,
    persist: true,
    defaultRoute: "persist",
    filename: './test/ut_8.nedb'
  },
  modules: {
    "pe": {
      path: "@smc/pe-component"
    },
    client: {
      path: ownPath,
      create: {
        name: 'Client',
        type: 'sync'
      }
    }
  },
  components: {
    data: {},
    "pe": {
      moduleName: "pe",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {port: EMU_PORT}
              }
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    client: {
      name: "client",
      moduleName: "client",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  serverMeshPort: SERVER_PORT,
                  serverMeshHost: SERVER_HOST,
                  serverComponentName: SERVER_COMPONENT_NAME,
                  protocol: 'http'
                }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      },
      web: {
        routes: {
          web: ["gzip", "checkIndex", "static"]
        }
      },
      data: {
        routes: {
          //'registrationData/*': 'persist'
        }
      }
    }
  }
};


var serverConfig = {
  name: SERVER_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: SERVER_PORT,
    persist: true,
    defaultRoute: 'mem'
  },
  modules: {
    server: {
      path: ownPath,
      create: {
        name: 'Server',
        type: 'sync'
      }
    }
  },
  components: {
    data: {},
    server: {
      name: 'server',
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options", "required": true, value: {
                deviceKeepaliveInterval: DEVICE_KEEPALIVE_INTERVAL,
                tunnelHealthInterval: TUNNEL_HEALTH_INTERVAL,
                tunnelServiceEndpoint: TUNNEL_SERVICE_ENDPOINT
              }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      }
    }
  }
};

var test_filename = path.basename(__filename);

describe(test_filename, function () {
  var clientMesh;
  var serverMesh;
  var fst_bridge_emu;

  before(function (done) {
    this.timeout(100000);
    var savedUser = null;
    var savedGroup = null;

    var db_src_path = path.join(__dirname, "./databases/ut_8.nedb");
    var db_dest_path = path.join(__dirname, "./ut_8.nedb");

    // make sure we get the unchanged db
    fs.exists(db_dest_path, function (exists) {
      if (exists) {
        fs.unlink(db_dest_path, link_old_db);
      }
      else {
        link_old_db();
      }
    });

    function link_old_db() {
      fs.link(db_src_path, db_dest_path, function () {
        fst_bridge_emu = FstBridgeEmu.emu({httpPort: EMU_PORT});
        fst_bridge_emu.on('online', function () {
          happner.create(serverConfig)
            .then(addGroup)
            .then(addUser)
            .then(linkUser)
            .then(createClient)
            .then(saveClient)
            .catch(function (err) {
              done(err);
            });
        });
      });
    }

    function addGroup(server) {
      serverMesh = server;
      return serverMesh.exchange.security.addGroup(getOemAdminGroup());
    }

    function addUser(group) {
      savedGroup = group;
      return serverMesh.exchange.security.addUser(OemAdmin);
    }

    function linkUser(user) {
      savedUser = user;
      return serverMesh.exchange.security.linkGroup(savedGroup, savedUser);
    }

    function createClient() {
      return happner.create(clientConfig);
    }

    function saveClient(client) {
      clientMesh = client;
      done();
    }
  });


  after(function (done) {
    async.parallel([
        function (cb) {
          if (!fst_bridge_emu) return cb();
          fst_bridge_emu.shutdown(cb);
        },
        function (cb) {
          if (!clientMesh) return cb();
          clientMesh.stop(cb)
        },
        function (cb) {
          if (!serverMesh) return cb();
          serverMesh.stop(cb);
        }],
      done
    );
  });

  // if the device was logged in and went offline,  then the server forgets about the device (db deleted)
  // when the client comes back online it will try to login,
  // if should get an invalid credential error and clear its internal credentials
  // once that happnes, the device should be able to register again.
  it('a - client should register a device on the server, if the server forgot about it', function (done) {
    this.timeout(100000);

    serverMesh.event.server.on("deviceRegistered/*", handleDeviceRegistrationEvent, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    serverMesh.event[SERVER_COMPONENT_NAME].on("deviceStatus/*", handleStatusEvent, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    var deviceDetails = {
      description: "FieldPoP test device 7",
      location: "10, 10",
      name: "Test device 7"
    };

    setTimeout(function () {
      clientMesh.exchange.client.registerDevice(OemAdmin, deviceDetails, function (err) {
        if (err) console.log(err);
        should.not.exist(err);
      });
    }, 1000);


    function handleDeviceRegistrationEvent(message) {
      message.should.property("deviceId");

      serverMesh.event.server.off("deviceRegistered/*", function (err) {
        if (err) console.log(err);
        should.not.exist(err);
      });
    }

    function handleStatusEvent(message) {
      message.should.property("deviceId");
      serverMesh.event[SERVER_COMPONENT_NAME].off("deviceStatus/*", function (err) {
        if (err) console.log(err);
        should.not.exist(err);
        done();
      });
    }
  });


  it('b - a device should be deregistered and device status evenets should stop', function (done) {
    this.timeout(10000);

    var deviceId = CLIENT_MESH_NAME;

    serverMesh.exchange.server.deregisterDevice(deviceId, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
      serverMesh.event[SERVER_COMPONENT_NAME].on("deviceStatus/*", handleStatusEvent, function (err) {
        if (err) console.log(err);
        should.not.exist(err);

      });

      // give the test some time to make sure there are no more status events
      setTimeout(checkNoEntry, 3000);
    });


    // We should not get any more status messages after devices deregister
    function handleStatusEvent(message) {
      should.not.exist(message);
    }

    function checkNoEntry() {
      var device_path = "deviceStatus/*/*/" + deviceId;
      var expected_path = "deviceStatus/" + OemUser.custom_data.oem + "/" + OemUser.custom_data.company + "/" + deviceId;

      serverMesh.exchange.data.get(device_path, function (err, data) {
        should.not.exist(err);
        data.length.should.eql(0);

        checkClientData();
      });
    }

    function checkClientData() {
      clientMesh.exchange.client.getDeviceDetials(function (data) {
        should.not.exist(data.tunnelHealthInterval);
        done();
      });
    }

  });
});


function getOemAdminGroup() {
  var regesterDeviceMethodPath = "/" + SERVER_MESH_NAME + "/" + SERVER_COMPONENT_NAME + "/registerDevice";

  var oemAdminGroup = {
    name: "OEM Admin",
    permissions: {
      methods: {}
    }
  };

  oemAdminGroup.permissions.methods[regesterDeviceMethodPath] = {authorized: true};

  return oemAdminGroup;
}

var OemUser = {
  username: 'user@oem.com',
  password: 'TEST PWD',
  custom_data: {
    oem: "OEM A",
    company: "Enterprise X"
  }
};


var OemAdmin = {
  username: 'admin@oem.com',
  password: 'TEST PWD',
  custom_data: {
    oem: "OEM A"
  }
};
