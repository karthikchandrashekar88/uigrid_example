var should = require('chai').should();
var happner = require('happner');
var path = require('path');
var FstBridgeEmu = require('@smc/fst_bridge_emu');
var async = require('async');
var shortid = require('shortid');

var ownPath = path.join(__dirname, '../index.js');

var SERVER_HOST = "localhost";
var SERVER_PORT = 8092;
var CLIENT_PORT = 8093;
var EMU_PORT = 8080;

var SERVER_COMPONENT_NAME = "server";
var SERVER_MESH_NAME = shortid.generate();
var CLIENT_MESH_NAME = shortid.generate() + "_client";

var DEVICE_KEEPALIVE_INTERVAL = 500;
var TUNNEL_HEALTH_INTERVAL = 5000;
var TUNNEL_SERVICE_ENDPOINT = "ws://192.168.1.5:8000";


var clientConfig = {
  name: CLIENT_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: CLIENT_PORT,
    persist: true,
    defaultRoute: "mem"
  },
  modules: {
    "pe": {
      path: "@smc/pe-component"
    },
    client: {
      path: ownPath,
      create: {
        name: 'Client',
        type: 'sync'
      }
    }
  },
  components: {
    data: {},
    "pe": {
      moduleName: "pe",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "sync",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {port: EMU_PORT}
              }
            ]
          },
          "stop": {
            type: "sync",
            parameters: []
          }
        }
      }
    },
    client: {
      name: "client",
      moduleName: "client",
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options",
                "required": true,
                value: {
                  serverMeshPort: SERVER_PORT,
                  serverMeshHost: SERVER_HOST,
                  serverComponentName: SERVER_COMPONENT_NAME,
                  protocol: 'http'
                }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      },
      web: {
        routes: {
          web: ["gzip", "checkIndex", "static"]
        }
      },
      data: {
        routes: {
          //'registrationData/*': 'persist'
        }
      }
    }
  }
};


var serverConfig = {
  name: SERVER_MESH_NAME,
  dataLayer: {
    secure: true,
    adminPassword: 'password',
    port: SERVER_PORT,
    persist: true,
    defaultRoute: 'mem'
  },
  modules: {
    server: {
      path: ownPath,
      create: {
        name: 'Server',
        type: 'sync'
      }
    }
  },
  components: {
    data: {},
    server: {
      name: 'server',
      scope: "component",
      startMethod: "start",
      stopMethod: "stop",
      schema: {
        "exclusive": false,
        "methods": {
          "start": {
            type: "async",
            parameters: [
              {
                "name": "options", "required": true, value: {
                deviceKeepaliveInterval: DEVICE_KEEPALIVE_INTERVAL,
                tunnelHealthInterval: TUNNEL_HEALTH_INTERVAL,
                tunnelServiceEndpoint: TUNNEL_SERVICE_ENDPOINT
              }
              }
            ]
          },
          "stop": {
            type: "sync"
          }
        }
      }
    }
  }
};

var test_filename = path.basename(__filename);

describe(test_filename, function () {
  var clientMesh;
  var serverMesh;
  var fst_bridge_emu;

  before(function (done) {
    var savedUser = null;
    var savedGroup = null;
    this.timeout(10000);


    fst_bridge_emu = FstBridgeEmu.emu({httpPort: EMU_PORT});
    fst_bridge_emu.on('online', function () {
      happner.create(serverConfig)
        .then(addGroup)
        .then(addUser)
        .then(linkUser)
        .then(createClient)
        .then(saveClient)
        .catch(function (err) {
          done(err);
        });
    });


    function addGroup(server) {
      serverMesh = server;
      return serverMesh.exchange.security.addGroup(getOemAdminGroup());
    }

    function addUser(group) {
      savedGroup = group;
      return serverMesh.exchange.security.addUser(OemAdmin);
    }

    function linkUser(user) {
      savedUser = user;
      return serverMesh.exchange.security.linkGroup(savedGroup, savedUser);
    }

    function createClient() {
      return happner.create(clientConfig);
    }

    function saveClient(client) {
      clientMesh = client;
      done();
    }
  });

  after(function (done) {
    async.parallel([
        function (cb) {
          if (!fst_bridge_emu) return cb();
          fst_bridge_emu.shutdown(cb);
        },
        function (cb) {
          if (!clientMesh) return cb();
          clientMesh.stop(cb)
        },
        function (cb) {
          if (!serverMesh) return cb();
          serverMesh.stop(cb);
        }],
      done
    );
  });

  it('a - client should register a device on the server', function (done) {
    this.timeout(10000);
    serverMesh.event.server.on("deviceRegistered/*", handleDeviceRegistrationEvent, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    serverMesh.event[SERVER_COMPONENT_NAME].on("deviceStatus/*", handleStatusEvent, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });


    var deviceDetails = {
      description: "FieldPoP test device",
      location: "10, 10",
      name: "Test device 1"
    };

    clientMesh.exchange.client.registerDevice(OemAdmin, deviceDetails, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    function handleDeviceRegistrationEvent(message) {
      message.should.property("macAddress");
      message.should.property("deviceId");
      message.should.property("description");
      message.should.property("location");
      message.should.property("deviceId");
      message.should.property("oem", OemAdmin.custom_data.oem);
      message.should.property("company", OemAdmin.custom_data.company);

      serverMesh.event.server.off("deviceRegistered/*", function (err) {
        if (err) console.log(err);
        should.not.exist(err);
      });
    }

    function handleStatusEvent(message) {
      message.should.property("deviceId");
      message.should.property("oem", OemAdmin.custom_data.oem);
      message.should.property("company", OemAdmin.custom_data.company);

      serverMesh.event[SERVER_COMPONENT_NAME].off("deviceStatus/*", function (err) {
        if (err) console.log(err);
        should.not.exist(err);

        var data_path = "*/" + message.deviceId;

        serverMesh.exchange.data.get(data_path, function (err, data) {
          if (err) console.log(err);
          should.not.exist(err);

          var expected_path = OemAdmin.custom_data.oem + "/" + OemAdmin.custom_data.company;
          var path_index = data[0]._meta.path.indexOf(expected_path);
          path_index.should.be.above(0);
          done();
        });
      });
    }
  });

  it('b - client should not be able to re-register a device', function (done) {
    this.timeout(5000);
    var deviceDetails = {
      description: "FieldPoP test device",
      location: "20, 20",
      name: "Test device 1"
    };

    clientMesh.exchange.client.registerDevice(OemAdmin, deviceDetails, function (err) {
      err.should.be.a('Error');
      err.message.should.eql('Device Already registered');
      done();
    });
  });

  it('c - client should update a device on the server', function (done) {
    this.timeout(5000);

    serverMesh.event[SERVER_COMPONENT_NAME].on("deviceStatus/*", handleStatusEvent, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    var deviceDetails = {
      description: "FieldPoP test device update",
      location: "40, 40 ",
      name: "New Test device 1"
    };

    clientMesh.exchange.client.updateDeviceDetails(deviceDetails, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    function handleStatusEvent(message) {
      message.should.property("macAddress");
      message.should.property("deviceId");
      message.should.property("description", deviceDetails.description);
      message.should.property("location", deviceDetails.location);
      message.should.property("name", deviceDetails.name);

      serverMesh.event[SERVER_COMPONENT_NAME].off("deviceStatus/*", function (err) {
        if (err) console.log(err);
        should.not.exist(err);

        done();
      });
    }
  });

  it('d - a registered device should be associated with a company and its data path updated', function (done) {
    this.timeout(50000);

    serverMesh.event[SERVER_COMPONENT_NAME].on("deviceStatus/*", handleStatusEvent, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
    });

    var deviceDetails = {
      description: "FieldPoP test device",
      location: "20, 20",
      name: "Test device 1"
    };

    var step = 0;

    var deviceId = CLIENT_MESH_NAME;

    serverMesh.exchange.server.setDeviceAssociation(deviceId, OemUser.custom_data.oem, OemUser.custom_data.company, function (err) {
      if (err) console.log(err);
      should.not.exist(err);
      step |= 0x01;

      if ((step & 0x03) == 0x03) {
        checkSingleEntry();
      }
    });

    function handleStatusEvent(message) {
      message.should.property('location');
      message.should.property('oem', OemUser.custom_data.oem);
      message.should.property('company', OemUser.custom_data.company);

      serverMesh.event[SERVER_COMPONENT_NAME].off("deviceStatus/*", function (err) {
        if (err) console.log(err);
        should.not.exist(err);
        step |= 0x02;

        if ((step & 0x03) == 0x03) {
          setTimeout(checkSingleEntry, 2000);
          //checkSingleEntry();
        }
      });
    }


    function checkSingleEntry() {
      var device_path = "deviceStatus/*/*/" + deviceId;
      var expected_path = "deviceStatus/" + OemUser.custom_data.oem + "/" + OemUser.custom_data.company + "/" + deviceId;

      serverMesh.exchange.data.get(device_path, function (err, data) {
        should.not.exist(err);
        data.length.should.eql(1);
        data[0]._meta.path.indexOf(expected_path).should.be.above(1);
        done();
      });
    }

  });
});


function getOemAdminGroup() {
  var regesterDeviceMethodPath = "/" + SERVER_MESH_NAME + "/" + SERVER_COMPONENT_NAME + "/registerDevice";

  var oemAdminGroup = {
    name: "OEM Admin",
    permissions: {
      methods: {}
    }
  };

  oemAdminGroup.permissions.methods[regesterDeviceMethodPath] = {authorized: true};

  return oemAdminGroup;
}

var OemUser = {
  username: 'user@oem.com',
  password: 'TEST PWD',
  custom_data: {
    oem: "OEM X",
    company: "Enterprise X"
  }
};


var OemAdmin = {
  username: 'admin@oem.com',
  password: 'TEST PWD',
  custom_data: {
    oem: "OEM A",
    company: "OEM A"
  }
};
