var gulp = require('gulp');
var argv = require('optimist').argv;
var jshint = require('gulp-jshint');
var concat = require('gulp-concat');
var uglify = require('gulp-uglify');
var runSequence = require('run-sequence');
var autoprefix = require('gulp-autoprefixer');
var source = require('vinyl-source-stream');
var watchify = require('watchify');
var browserify = require('browserify');
var zip = require('gulp-zip');
var gzip = require('gulp-gzip');
var gulpif = require('gulp-if');
var buffer = require('vinyl-buffer');
var minifyCSS = require('gulp-minify-css');
var minifyHtml = require('gulp-minify-html');
var del = require('del');
var _ = require('lodash');

var unzip = require('gulp-unzip');
var run = require('gulp-run');
var rimraf = require('gulp-rimraf');
var download = require("gulp-download");
var git = require('gulp-git');

var fst_gulp_tasks = require('@smc/fst_gulp_tasks');

var path = require('path');


var isProduction = argv.production;
var testServer = argv.testServer;

var includeConfigCsv = true;
var developmentMode = false;

var devDependencies=['happner','@smc/proxy_component'];

var cssSources = [
    './node_modules/bootstrap/dist/css/bootstrap.min.css',
    './node_modules/@smc/scci_directive_flat/scci_flat.css',
    './node_modules/@smc/alert-directive/dist/css/styles.css',
    './node_modules/ng-dialog/css/ngDialog.min.css',
    './node_modules/ng-dialog/css/ngDialog-theme-default.css',
    './lib/web/css/app.css'
];

var jsSources = [
    './node_modules/angular/angular.js',
    './node_modules/jquery/dist/jquery.js',
    './node_modules/bootstrap/dist/js/bootstrap.min.js',
    './node_modules/@smc/alert-directive/dist/index-browser.js',
    './node_modules/@smc/scci_directive_flat/scci_flat.min.js',
    './node_modules/ngmap/build/scripts/ng-map.min.js',
    './node_modules/angular-ui-bootstrap/dist/ui-bootstrap-tpls.js',
    './node_modules/ng-dialog/js/ngDialog.min.js',
    './lib/web/js/ngPlacesAutocomplete.js'
    // CC: keeping this here for now. We need to try and get back to the published version of this module once it is updated
    //'./node_modules/ng-places-autocomplete/ngPlacesAutocomplete.min.js'
];

var htmlSources = [
    './lib/web/*.html'
];

var appScripts = "./lib/web/js/*.js";

var lintSrc = ['./lib/**/*.js'];


var buildRoot = argv.build_target ? argv.build_target : './build';
var appRoot = path.join(buildRoot, '/node_js/app');
var packageRoot = argv.pack_target ? argv.pack_target : './package';
var webPackageRoot = argv.web_target ? argv.web_target : path.join(appRoot, 'client');
var webPackageDist = path.join(webPackageRoot, 'dist');
var configRoot = argv.config_target ? argv.config_target : path.join(appRoot, 'config');
var bundler;
var bundlerController;
var livereloadOptions = {auto: false};

gulp.task('lint', function () {
    return gulp.src(lintSrc)
        .pipe(jshint())
        .pipe(jshint.reporter('default'));
});

gulp.task('browserify', function () {
    if (bundler) return;

    if (developmentMode) {
        bundler = watchify('./lib/web/js/index.js');
        bundler.on('update', rebundle);
    }
    else {
        bundler = browserify('./lib/web/js/index.js');
    }
    bundler.on('log', function (msg) {
        console.log('browserify: ' + msg);
    });

    function rebundle() {
        var bundle = bundler.bundle()
            .on('error', function (e) {
                //  https://github.com/substack/watchify/issues/27
                //  watchify stops watching a file after an error
                console.log('Browserify Error - please fix error and restart gulp (or automate this): ' + e);
                process.exit();
            })
            .pipe(source('app.min.js'))
            .pipe(gulpif(isProduction, buffer()))
            .pipe(gulpif(isProduction, uglify()))
            .pipe(gzip())
            .pipe(gulp.dest(webPackageRoot + '/js'));

        bundle.on('end', function () {
            //gulp.start('pack');
        });

        return bundle;
    }

    return rebundle();
});

gulp.task('app_scripts', function () {
    return gulp.src(jsSources)
        .pipe(concat('modules.js'))
        .pipe(gzip())
        .pipe(gulp.dest(webPackageRoot + '/js'));
});

gulp.task('app_controller', function () {
  if (bundlerController) return;

  if (developmentMode) {
    bundlerController = watchify('./lib/web/js/dist.js');
    bundlerController.on('update', rebundle);
  }
  else {
    bundlerController = browserify('./lib/web/js/dist.js');
  }
  bundlerController.on('log', function (msg) {
    console.log('browserify: ' + msg);
  });

  function rebundle() {
    var bundle = bundlerController.bundle()
      .on('error', function (e) {
        //  https://github.com/substack/watchify/issues/27
        //  watchify stops watching a file after an error
        console.log('Browserify Error - please fix error and restart gulp (or automate this): ' + e);
        process.exit();
      })
      .pipe(source('controller.min.js'))
      .pipe(gulpif(isProduction, buffer()))
      .pipe(gulpif(isProduction, uglify()))
      //.pipe(gzip())
      .pipe(gulp.dest(webPackageDist));

    bundle.on('end', function () {
      //gulp.start('pack');
    });

    return bundle;
  }

  return rebundle();
});

gulp.task('styleDist', function () {
  console.log(webPackageDist);
  return gulp.src('./lib/web/css/app.css')
    .pipe(concat('all.min.css'))
    //.pipe(autoprefix('last 2 versions'))
    .pipe(gulpif(isProduction, minifyCSS()))
    .pipe(gzip())
    .pipe(gulp.dest(webPackageDist));
});

gulp.task('customDist', function(){
  return gulp.src('./lib/web/js/ngPlacesAutocomplete.js')
      .pipe(concat('custom-modules.js'))
      .pipe(gulpif(isProduction, buffer()))
      .pipe(gulpif(isProduction, uglify()))
      .pipe(gzip())
      .pipe(gulp.dest(webPackageDist));
});

gulp.task('htm', function () {
    return gulp.src(htmlSources)
        .pipe(gulpif(isProduction, minifyHtml({empty: true})))
        //.pipe(gzip())
        .pipe(gulp.dest(webPackageRoot));
});

gulp.task('fonts', function () {
  return gulp.src('./node_modules/bootstrap/dist/fonts/*')
      .pipe(gulp.dest(webPackageRoot + '/fonts'));
});

gulp.task('images', function () {
  return gulp.src('./lib/web/images/*')
    .pipe(gulp.dest(webPackageRoot + '/images'));
});

gulp.task('styles', function () {
    return gulp.src(cssSources)
        .pipe(concat('all.min.css'))
        //.pipe(autoprefix('last 2 versions'))
        .pipe(gulpif(isProduction, minifyCSS()))
        .pipe(gzip())
        .pipe(gulp.dest(webPackageRoot + '/css'));
});


gulp.task('copy_config', function () {
    return gulp.src('./lib/config/**/*')
        .pipe(gulp.dest(configRoot));
});


gulp.task('install_package', function () {
  var arm_env = _.clone(process.env);
  arm_env.CC = "arm-none-linux-gnueabi-gcc";
  arm_env.CXX = "arm-none-linux-gnueabi-g++";
    return run('npm install --production --arch=arm', {cwd: appRoot, env:arm_env, verbosity:3}).exec();
});

var next_pkg = null;

gulp.task('install_devDependencies_list', function(callback){
  function installNextOrExit(){
    if(devDependencies.length > 0){
      next_pkg = devDependencies.shift();
      console.log("---Install", next_pkg);
      runSequence('install_devDependencies', installNextOrExit);
    }
    else{
      callback();
    }
  }

  installNextOrExit();
});

gulp.task('install_devDependencies', function() {
  var arm_env = _.clone(process.env);
  arm_env.CC = "arm-none-linux-gnueabi-gcc";
  arm_env.CXX = "arm-none-linux-gnueabi-g++";
  var package_json = require(path.join(__dirname, "package.json"));
  var package_version = package_json.devDependencies[next_pkg];
  var install_command = "npm install " + next_pkg + "@" + package_version + " --arch=arm";
  return run(install_command, {cwd: appRoot, env:arm_env, verbosity:3}).exec();
});

gulp.task('clean', function () {
    return gulp.src([buildRoot, packageRoot], {read: false}) // much faster
        .pipe(rimraf());
});

gulp.task('remove_git', function () {
    return gulp.src(GIT_PATH, {read: false})
        .pipe(rimraf());
});

gulp.task('node_root_files', function () {
    return gulp.src(['./happner.js', './index.js', './package.json'])
        .pipe(gulp.dest(appRoot));
});

gulp.task('mesh_config', function () {
    return gulp.src(['./brain_config.js'])
        .pipe(gulp.dest(appRoot));
});

gulp.task('lib', function () {
    return gulp.src(['./lib/*.js'])
        .pipe(gulp.dest(appRoot + "/lib"));
});


gulp.task('update_bin', function () {
    return gulp.src(['./update_files/**/*'])
        .pipe(gulp.dest(buildRoot));
});

gulp.task('build_update_bin', function () {
    return gulp.src(buildRoot + '/**/*')
        .pipe(zip('update.bin'))
        .pipe(gulp.dest(packageRoot));
});

gulp.task('clean', function () {
    return gulp.src([buildRoot, packageRoot], {read: false}) // much faster
        .pipe(rimraf());
});

gulp.task('pack', function (callback) {
    runSequence(
        'clean',
        'lint',
        'node_root_files',
        'lib',
        'install_package',
        'install_devDependencies_list',
        'copy_config',
        ['browserify', 'htm', 'styles', 'fonts', 'images', 'app_scripts', 'app_controller', 'styleDist'],
        'update_bin',
        'build_update_bin',
        //'pack_tar',
        callback
    );
});


gulp.task('set_local_path', function (callback) {
    webPackageRoot = './client';
    webPackageDist = path.join(webPackageRoot, 'dist');
    configRoot = "./config";
    callback();
});


gulp.task('pack_lib', function (callback) {
    runSequence(
        'lib',
        //'mesh_config',
        'copy_config',
        ['browserify', 'htm', 'styles', 'fonts', 'images', 'app_scripts', 'app_controller', 'styleDist'],
        'update_bin',
        'build_update_bin',
        //'pack_tar',

        callback
    );
});


gulp.task('pack_local', function (callback) {
    runSequence(
        'set_local_path',
        'copy_config',
        ['browserify', 'htm', 'styles', 'fonts', 'images',  'app_scripts', 'app_controller', 'styleDist', 'customDist'],
        callback
    );
});

// Default Task
// note that concat is triggered by watchify
gulp.task('default', ['pack', 'pack_local']);
